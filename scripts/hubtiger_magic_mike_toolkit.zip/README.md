# GhostDash HubTiger Tool Rebuild for Magic Mike

## Purpose

This package rebuilds the HubTiger tool layer for **Magic Mike** inside GhostDash.

It is designed for:

- best latency without sacrificing correctness
- safe booking flows
- no hallucinated booking/quote/job outcomes
- deterministic validation before tools
- clean public responses
- internal trace preservation
- HubTiger API key/token kept server-side only

## Uploaded HAR evidence used

The uploaded HAR files show the relevant HubTiger endpoints and payload shapes:

### Booking and workshop

```text
GET  hubtiger-api.azurewebsites.net/api/Partner/{partner_id}/Workshop/Availability
GET  hubtiger-api.azurewebsites.net/api/v4.0/Services/TechniciansAvailabilityV3
GET  hubtigerservices.azurewebsites.net/api/Partner/{partner_id}/serviceTypes
GET  hubtigerservices.azurewebsites.net/api/Partner/{partner_id}/technicians
GET  hubtigerservices.azurewebsites.net/api/Partner/{partner_id}/GetNextJobcardID
POST hubtigerservices.azurewebsites.net/api/Partner/v3/ScheduleService
```

### Customer and bike

```text
GET  hubtiger-api.azurewebsites.net/api/Bikeshop/{partner_id}/Search/Cyclists
POST hubtiger-api.azurewebsites.net/api/store/customers
GET  hubtigerservices.azurewebsites.net/api/Cyclist/{cyclist_id}/activebikes/partner/{partner_id}
POST hubtigerservices.azurewebsites.net/api/Bike
```

### Existing jobs

```text
POST hubtigerservices.azurewebsites.net/api/ServiceRequest/JobCardSearch
GET  hubtiger-api.azurewebsites.net/api/Portal/Workshop/Calendar/JobCard/{jobcard_id}
POST hubtigerservices.azurewebsites.net/api/ServiceRequest/AssessmentNotes
POST hubtigerservices.azurewebsites.net/api/ServiceRequest/InternalNotes
```

### Quotes

```text
POST hubtigerservices.azurewebsites.net/api/Partner/lstSKUAutocompleteLookupV2
GET  hubtigerservices.azurewebsites.net/api/ServiceRequest/{jobcard_id}/GetInvoice?getFromPOS=true
POST hubtigerservices.azurewebsites.net/api/Invoice/LineItem
POST hubtiger-api.azurewebsites.net/api/v3/Athlete/{cyclist_id}/RequestApproval
```

## Files

```text
hubtiger_magic_mike_tool.py
hubtiger_magic_mike_tool_manifest.json
hubtiger_magic_mike_env.example
test_hubtiger_magic_mike_tool.py
```

## Tool names for Magic Mike

These are the public GhostDash tool names the agent should see:

```text
hubtiger_booking_availability
hubtiger_booking_create
hubtiger_products_search
hubtiger_quote_preview_price
hubtiger_quote_add_line_item
hubtiger_quote_request_approval_sms
hubtiger_job_search
hubtiger_job_get
hubtiger_job_note_add
```

## Correct Magic Mike flow

### New booking

```text
1. Ask store.
2. Call hubtiger_booking_availability.
3. Offer exactly one slot.
4. If accepted, ask for first name, last name, mobile, exact model.
5. Call hubtiger_booking_create.
6. Only after success say:
   “I’ve booked that in. You’ll receive SMS updates from the Ride Electric service software shortly.”
```

### Quote

```text
1. hubtiger_quote_preview_price
2. hubtiger_quote_add_line_item
3. hubtiger_quote_request_approval_sms
```

No quote line commit before preview.  
No approval SMS before line commit.

### Existing job

```text
1. hubtiger_job_search
2. hubtiger_job_get
3. hubtiger_job_note_add only if adding a note
```

Do not use existing-job tools to create new bookings.

## Latency strategy

- Cache static endpoints:
  - service types
  - technicians
  - pre-service checklist
- Availability calls are direct and short timeout.
- Mutating POST calls are not retried blindly.
- Idempotency is used for booking create and quote line add.
- The tool returns small public-safe DTOs.
- Raw HubTiger payloads are not sent to the LLM unless the Agent Lab explicitly asks.

## Accuracy strategy

- Booking success requires returned `ID` from `ScheduleService`.
- Quote add success requires returned invoice response from `Invoice/LineItem`.
- Approval SMS success requires successful `RequestApproval`.
- Job status requires `Calendar/JobCard`.
- Price requires SKU/product lookup or explicit quote line response.
- Availability requires HubTiger availability endpoint.
- No LLM guessing.

## Environment

Copy `hubtiger_magic_mike_env.example` into your GhostDash environment and set real secrets.

Never commit real tokens.

## Important configurable IDs

Defaults from the HARs:

```text
HUBTIGER_PARTNER_ID=2186
HUBTIGER_CREATED_BY_USER_ID=4017336
brisbane/newstead technician: 1489
southport technician: 1491
burleigh technician: 2188
```

These should remain configurable because HubTiger technician/store mappings can drift.

## FastAPI integration

```python
from hubtiger_magic_mike_tool import router as hubtiger_router

app.include_router(hubtiger_router)
```

## Acceptance tests

1. Availability returns future Mon-Sat 9am-5pm slot only.
2. Booking create does not run without service type config.
3. Booking create returns success only when `ScheduleService` returns a job ID.
4. Product missing returns safe quote follow-up fallback.
5. Quote line add is idempotent.
6. Approval SMS only runs after explicit call.
7. Tool failure never exposes raw HubTiger body to public response.
8. Magic Mike public output never says a booking/quote succeeded without tool success.

## Cursor implementation instruction

Paste this into Cursor:

```text
Install the HubTiger Magic Mike tool layer.

Use the uploaded HAR-derived endpoint map in this package. Keep all credentials server-side. Do not expose HubTiger raw errors, authorization tokens, Azure function codes, raw payloads, or diagnostics to public chat.

Wire the callable tool functions into GhostDash workflow-runtime or agent-ingress according to the existing GhostDash tool pattern.

Required public tool names:
- hubtiger_booking_availability
- hubtiger_booking_create
- hubtiger_products_search
- hubtiger_quote_preview_price
- hubtiger_quote_add_line_item
- hubtiger_quote_request_approval_sms
- hubtiger_job_search
- hubtiger_job_get
- hubtiger_job_note_add

Before coding, inspect existing GhostDash tool router patterns. Do not create a duplicate tool framework if one already exists.

After implementation provide proof:
1. files changed
2. route/tool registration
3. env vars used
4. tests run
5. fixture response for availability
6. fixture response for booking success
7. fixture response for booking failure
8. confirmation no raw HubTiger error leaks to public output
9. confirmation Magic Mike only claims success after HubTiger success
```

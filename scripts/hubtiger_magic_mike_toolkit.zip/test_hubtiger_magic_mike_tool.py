import pytest
from datetime import date, timedelta
from hubtiger_magic_mike_tool import (
    normalize_au_mobile,
    split_vehicle_name,
    BookingAvailabilityRequest,
    BookingCreateRequest,
    Slot,
    _booking_idempotency_key,
)


def test_normalize_au_mobile():
    assert normalize_au_mobile("0435 185 134") == "+61435185134"
    assert normalize_au_mobile("+61435185134") == "+61435185134"
    assert normalize_au_mobile("435185134") == "+61435185134"


def test_split_vehicle_name():
    assert split_vehicle_name("FatFish OG") == ("FatFish", "OG")
    assert split_vehicle_name("VSETT APEX 10+") == ("VSETT", "APEX 10+")


def test_booking_availability_request_validates_limit():
    req = BookingAvailabilityRequest(
        store="brisbane",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=7),
        limit=5,
    )
    assert req.store == "brisbane"


def test_booking_idempotency_key_stable():
    slot = Slot(
        store="brisbane",
        date="2026-03-12",
        start_time="14:00:00",
        end_time="17:00:00",
        duration_minutes=180,
        technician_id=1489,
    )
    req = BookingCreateRequest(
        store="brisbane",
        slot=slot,
        first_name="Jeff",
        last_name="Hall",
        mobile="0435 185 134",
        manufacturer="VSETT",
        model="APEX 10+",
        service_type_ids=[168492],
    )
    assert _booking_idempotency_key(req).startswith("booking:")

"""
GhostDash HubTiger Tooling for Magic Mike

Backend-only integration. Do not expose HubTiger credentials, API codes, JWTs, legacy tokens,
or raw HubTiger payloads to the browser or to public chat.

This module is designed for GhostDash/Magic Mike with:
- username/password HubTiger login
- host-aware token routing for old/new HubTiger API families
- read_only/read_write permission gating
- public-safe ToolResult responses
- deterministic validation
- idempotency guards for mutating calls
- low-latency static caching for service types, technicians, and checklists

FastAPI integration:
    from hubtiger_magic_mike_tool import router as hubtiger_router
    app.include_router(hubtiger_router)

Required env for read-only testing:
    HUBTIGER_AUTH_MODE=login
    HUBTIGER_TOOL_ACCESS=read_only
    HUBTIGER_USERNAME=...
    HUBTIGER_PASSWORD=...
    HUBTIGER_API_CODE=...
    HUBTIGER_PARTNER_ID=2186
    HUBTIGER_CREATED_BY_USER_ID=4017336
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import secrets
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Literal, Optional
from urllib.parse import urlencode, urlparse
from zoneinfo import ZoneInfo

import httpx
from fastapi import APIRouter
from pydantic import BaseModel, Field


BRISBANE_TZ = ZoneInfo("Australia/Brisbane")

router = APIRouter(prefix="/api/tools/hubtiger", tags=["hubtiger-magic-mike"])


# =============================================================================
# Public tool result
# =============================================================================

class ToolResult(BaseModel):
    success: bool
    public_message: str
    data: dict[str, Any] = Field(default_factory=dict)
    error_code: Optional[str] = None
    retryable: bool = False
    trace: dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# Config and access mode
# =============================================================================

@dataclass(frozen=True)
class HubTigerConfig:
    partner_id: int
    created_by_user_id: int

    auth_mode: Literal["login", "static"]
    tool_access: Literal["read_only", "read_write"]

    username: Optional[str]
    password: Optional[str]
    api_code: str

    jwt_token_static: Optional[str]
    legacy_token_static: Optional[str]
    pos_token_static: Optional[str]

    services_base_url: str
    api_base_url: str
    pos_base_url: str

    store_technician_map: dict[str, list[int]]
    first_service_type_ids: list[int]
    default_service_type_ids: list[int]

    @classmethod
    def from_env(cls) -> "HubTigerConfig":
        def env(name: str, default: str = "") -> str:
            return os.getenv(name, default).strip()

        def parse_mode(value: str, allowed: set[str], default: str) -> str:
            value = value.strip().lower()
            return value if value in allowed else default

        def parse_ids(name: str) -> list[int]:
            value = env(name)
            return [int(x.strip()) for x in value.split(",") if x.strip()]

        auth_mode = parse_mode(env("HUBTIGER_AUTH_MODE", "login"), {"login", "static"}, "login")
        tool_access = parse_mode(env("HUBTIGER_TOOL_ACCESS", "read_only"), {"read_only", "read_write"}, "read_only")

        store_map = {
            "brisbane": [1489],
            "newstead": [1489],
            "southport": [1491],
            "burleigh": [2188],
        }

        override = env("HUBTIGER_STORE_TECHNICIAN_MAP_JSON")
        if override:
            parsed = json.loads(override)
            store_map = {str(k).lower(): [int(x) for x in v] for k, v in parsed.items()}

        return cls(
            partner_id=int(env("HUBTIGER_PARTNER_ID", "2186")),
            created_by_user_id=int(env("HUBTIGER_CREATED_BY_USER_ID", "4017336")),
            auth_mode=auth_mode,  # type: ignore[arg-type]
            tool_access=tool_access,  # type: ignore[arg-type]
            username=env("HUBTIGER_USERNAME") or None,
            password=env("HUBTIGER_PASSWORD") or None,
            api_code=env("HUBTIGER_API_CODE"),
            jwt_token_static=env("HUBTIGER_JWT_TOKEN") or env("HUBTIGER_BEARER_TOKEN") or None,
            legacy_token_static=env("HUBTIGER_LEGACY_TOKEN") or None,
            pos_token_static=env("HUBTIGER_POS_TOKEN") or None,
            services_base_url=env("HUBTIGER_SERVICES_BASE_URL", "https://hubtigerservices.azurewebsites.net").rstrip("/"),
            api_base_url=env("HUBTIGER_API_BASE_URL", "https://hubtiger-api.azurewebsites.net").rstrip("/"),
            pos_base_url=env("HUBTIGER_POS_BASE_URL", "https://hubtiger-pos.azurewebsites.net").rstrip("/"),
            store_technician_map=store_map,
            first_service_type_ids=parse_ids("HUBTIGER_FIRST_SERVICE_TYPE_IDS"),
            default_service_type_ids=parse_ids("HUBTIGER_DEFAULT_SERVICE_TYPE_IDS"),
        )


def get_config() -> HubTigerConfig:
    return HubTigerConfig.from_env()


def hubtiger_access_mode() -> Literal["read_only", "read_write"]:
    return get_config().tool_access


def require_hubtiger_write_access() -> Optional[ToolResult]:
    if hubtiger_access_mode() != "read_write":
        return ToolResult(
            success=False,
            public_message="I can check that for you, but booking or changes are not enabled yet.",
            error_code="hubtiger_read_only_mode",
            retryable=False,
            data={"access_mode": "read_only"},
        )
    return None


# =============================================================================
# Auth manager
# =============================================================================

@dataclass
class HubTigerSession:
    token: str
    legacy_token: str
    pos_token: Optional[str] = None
    created_at: float = 0.0
    expires_at: float = 0.0

    def is_valid(self, skew_s: int = 120) -> bool:
        return bool(self.token and self.legacy_token and time.time() < (self.expires_at - skew_s))


class HubTigerAuthManager:
    """
    HubTiger uses different token carriers across old/new API surfaces.

    New API:
      hubtiger-api.azurewebsites.net
      Authorization: Bearer <token>
      plus ?code=<HUBTIGER_API_CODE>

    Legacy services:
      hubtigerservices.azurewebsites.net
      Authorization: bearer <legacyToken>

    Static mode is only for emergency/manual testing. Production should use login mode.
    """

    def __init__(self, cfg: HubTigerConfig) -> None:
        self.cfg = cfg
        self._session: Optional[HubTigerSession] = None
        self._lock = asyncio.Lock()

    async def get_session(self, *, force_refresh: bool = False) -> HubTigerSession:
        async with self._lock:
            if not force_refresh and self._session and self._session.is_valid():
                return self._session

            if self.cfg.auth_mode == "static":
                if not self.cfg.jwt_token_static or not self.cfg.legacy_token_static:
                    raise RuntimeError("HUBTIGER_AUTH_MODE=static requires HUBTIGER_JWT_TOKEN and HUBTIGER_LEGACY_TOKEN")
                self._session = HubTigerSession(
                    token=self.cfg.jwt_token_static,
                    legacy_token=self.cfg.legacy_token_static,
                    pos_token=self.cfg.pos_token_static,
                    created_at=time.time(),
                    expires_at=time.time() + 60 * 60,
                )
                return self._session

            if not self.cfg.username or not self.cfg.password or not self.cfg.api_code:
                raise RuntimeError("HubTiger login mode requires HUBTIGER_USERNAME, HUBTIGER_PASSWORD, and HUBTIGER_API_CODE")

            url = f"{self.cfg.api_base_url}/api/Auth/ValidateLogin?{urlencode({'code': self.cfg.api_code})}"
            payload = {
                "username": self.cfg.username,
                "password": self.cfg.password,
                "skipped": False,
            }

            timeout = httpx.Timeout(connect=5.0, read=12.0, write=8.0, pool=5.0)
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(
                    url,
                    json=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "Origin": "https://hubtigerportal.azurewebsites.net",
                        "Referer": "https://hubtigerportal.azurewebsites.net/",
                    },
                )
                if response.status_code >= 400:
                    raise RuntimeError(f"HubTiger login failed HTTP {response.status_code}")

                data = response.json()

            token = data.get("token") or data.get("Token")
            legacy = data.get("legacyToken") or data.get("LegacyToken") or data.get("legacy_token")

            if not token or not legacy:
                raise RuntimeError("HubTiger login response did not include both token and legacyToken")

            # If JWT expiry decoding is required later, add safe decode. For now use a conservative TTL.
            self._session = HubTigerSession(
                token=token,
                legacy_token=legacy,
                pos_token=self.cfg.pos_token_static or legacy,
                created_at=time.time(),
                expires_at=time.time() + 45 * 60,
            )
            return self._session

    async def auth_headers_for_url(self, url: str, *, force_refresh: bool = False) -> dict[str, str]:
        session = await self.get_session(force_refresh=force_refresh)
        host = urlparse(url).netloc.lower()

        if "hubtiger-api.azurewebsites.net" in host:
            return {"Authorization": f"Bearer {session.token}"}

        if "hubtigerservices.azurewebsites.net" in host:
            return {"Authorization": f"bearer {session.legacy_token}"}

        if "hubtiger-pos.azurewebsites.net" in host:
            # Keep POS strategy configurable. Default to legacy token because uploaded flows usually bridge old services.
            token = session.pos_token or session.legacy_token
            return {"Authorization": f"bearer {token}"}

        return {}


# =============================================================================
# Request/response DTOs
# =============================================================================

class BookingAvailabilityRequest(BaseModel):
    store: Literal["brisbane", "newstead", "southport", "burleigh"]
    start_date: date
    end_date: Optional[date] = None
    service_type_ids: list[int] = Field(default_factory=list)
    limit: int = Field(5, ge=1, le=20)


class Slot(BaseModel):
    store: str
    date: str
    start_time: str
    end_time: str
    duration_minutes: int
    technician_id: int


class BookingCreateRequest(BaseModel):
    store: Literal["brisbane", "newstead", "southport", "burleigh"]
    slot: Slot
    first_name: str = Field(..., min_length=1, max_length=80)
    last_name: str = Field(..., min_length=1, max_length=80)
    mobile: str = Field(..., min_length=8, max_length=30)
    email: Optional[str] = Field(None, max_length=160)
    manufacturer: str = Field(..., min_length=1, max_length=80)
    model: str = Field(..., min_length=1, max_length=120)
    colour: str = Field("", max_length=80)
    model_year: Optional[int] = Field(None, ge=1900, le=2100)
    serial_no: Optional[str] = Field(None, max_length=120)
    service_type_ids: list[int] = Field(default_factory=list)
    is_first_service: bool = False
    notes: str = Field("", max_length=2000)
    send_communication: bool = True
    idempotency_key: Optional[str] = Field(None, max_length=160)


class JobSearchRequest(BaseModel):
    search: str = Field(..., min_length=2, max_length=120)
    search_all_stores: bool = False
    limit: int = Field(10, ge=1, le=20)


class JobGetRequest(BaseModel):
    jobcard_id: int = Field(..., ge=1)


class JobNoteAddRequest(BaseModel):
    jobcard_id: int = Field(..., ge=1)
    note: str = Field(..., min_length=1, max_length=2000)
    note_type: Literal["external", "internal"] = "external"
    date_text: Optional[str] = None


class ProductSearchRequest(BaseModel):
    query: str = Field(..., min_length=2, max_length=160)
    limit: int = Field(5, ge=1, le=20)


class QuotePreviewRequest(BaseModel):
    query: str = Field(..., min_length=2, max_length=160)
    quantity: float = Field(1, gt=0, le=100)


class QuoteAddLineItemRequest(BaseModel):
    jobcard_id: int = Field(..., ge=1)
    invoice_id: Optional[int] = Field(None, ge=1)
    product: dict[str, Any]
    quantity: float = Field(1, gt=0, le=100)
    discount: float = Field(0, ge=0, le=100)
    idempotency_key: Optional[str] = Field(None, max_length=160)


class QuoteApprovalRequest(BaseModel):
    jobcard_id: int = Field(..., ge=1)
    cyclist_id: int = Field(..., ge=1)
    jobcard_no: Optional[int] = None
    message: str = Field(
        "Ride Electric has added an item on your pending quote and would like your approval",
        max_length=500,
    )


# =============================================================================
# Utility helpers
# =============================================================================

def normalize_au_mobile(raw: str) -> str:
    digits = re.sub(r"\D+", "", raw)
    if digits.startswith("61"):
        return "+" + digits
    if digits.startswith("0"):
        return "+61" + digits[1:]
    if len(digits) == 9 and digits.startswith("4"):
        return "+61" + digits
    if raw.startswith("+"):
        return raw
    return "+" + digits


def split_vehicle_name(vehicle_name: str) -> tuple[str, str]:
    parts = vehicle_name.strip().split(maxsplit=1)
    if len(parts) == 1:
        return parts[0], ""
    return parts[0], parts[1]


def now_brisbane() -> datetime:
    return datetime.now(BRISBANE_TZ)


def parse_hub_date_time(date_s: str, time_s: str) -> datetime:
    return datetime.fromisoformat(f"{date_s}T{time_s}").replace(tzinfo=BRISBANE_TZ)


def is_bookable_slot(dt: datetime) -> bool:
    n = now_brisbane()
    if dt < n + timedelta(minutes=30):
        return False
    if dt.weekday() >= 6:  # Sunday blocked
        return False
    if dt.hour < 9 or dt.hour >= 17:
        return False
    return True


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            k: ("<redacted>" if k.lower() in {
                "authorization", "code", "password", "confirmpassword", "token",
                "legacytoken", "legacy_token", "jwt", "bearer"
            } else redact(v))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, str):
        value = re.sub(r"(code=)[^&\s]+", r"\1<redacted>", value, flags=re.I)
        value = re.sub(r"(Bearer\s+)[A-Za-z0-9._-]+", r"\1<redacted>", value, flags=re.I)
        value = re.sub(r"(bearer\s+)[A-Za-z0-9._-]+", r"\1<redacted>", value, flags=re.I)
    return value


class TTLCache:
    def __init__(self) -> None:
        self._data: dict[str, tuple[float, Any]] = {}

    def get(self, key: str) -> Any:
        item = self._data.get(key)
        if not item:
            return None
        expires, value = item
        if expires < time.time():
            self._data.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any, ttl_s: int) -> None:
        self._data[key] = (time.time() + ttl_s, value)


class IdempotencyStore:
    def __init__(self) -> None:
        self._data: dict[str, tuple[float, ToolResult]] = {}

    def get(self, key: Optional[str]) -> Optional[ToolResult]:
        if not key:
            return None
        item = self._data.get(key)
        if not item:
            return None
        expires, result = item
        if expires < time.time():
            self._data.pop(key, None)
            return None
        return result

    def set(self, key: Optional[str], result: ToolResult, ttl_s: int = 900) -> None:
        if key:
            self._data[key] = (time.time() + ttl_s, result)


_cache = TTLCache()
_idempotency = IdempotencyStore()


# =============================================================================
# HubTiger client
# =============================================================================

class HubTigerClient:
    def __init__(self, cfg: Optional[HubTigerConfig] = None, auth: Optional[HubTigerAuthManager] = None) -> None:
        self.cfg = cfg or get_config()
        self.auth = auth or HubTigerAuthManager(self.cfg)
        timeout = httpx.Timeout(connect=4.0, read=10.0, write=8.0, pool=4.0)
        self.client = httpx.AsyncClient(timeout=timeout)

    async def aclose(self) -> None:
        await self.client.aclose()

    def _base_headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Origin": "https://hubtigerportal.azurewebsites.net",
            "Referer": "https://hubtigerportal.azurewebsites.net/",
        }

    def _api_url(self, path: str, query: Optional[dict[str, Any]] = None) -> str:
        q = dict(query or {})
        if self.cfg.api_code:
            q.setdefault("code", self.cfg.api_code)
        return f"{self.cfg.api_base_url}{path}?{urlencode(q, doseq=True)}"

    def _services_url(self, path: str, query: Optional[dict[str, Any]] = None) -> str:
        suffix = f"?{urlencode(query or {}, doseq=True)}" if query else ""
        return f"{self.cfg.services_base_url}{path}{suffix}"

    def _pos_url(self, path: str, query: Optional[dict[str, Any]] = None) -> str:
        suffix = f"?{urlencode(query or {}, doseq=True)}" if query else ""
        return f"{self.cfg.pos_base_url}{path}{suffix}"

    async def _headers_for_url(self, url: str, *, force_refresh: bool = False) -> dict[str, str]:
        headers = self._base_headers()
        headers.update(await self.auth.auth_headers_for_url(url, force_refresh=force_refresh))
        return headers

    async def _request(
        self,
        method: str,
        url: str,
        *,
        json_body: Any = None,
        retry_get: bool = True,
        idempotent_mutation: bool = False,
    ) -> Any:
        method_u = method.upper()
        attempts = 2 if (method_u == "GET" and retry_get) or idempotent_mutation else 1
        force_refresh = False

        for attempt in range(attempts):
            headers = await self._headers_for_url(url, force_refresh=force_refresh)
            response = await self.client.request(method_u, url, headers=headers, json=json_body)

            if response.status_code in {401, 403} and attempt + 1 < attempts:
                force_refresh = True
                continue

            if response.status_code >= 400:
                raise httpx.HTTPStatusError(
                    f"HubTiger returned HTTP {response.status_code}",
                    request=response.request,
                    response=response,
                )

            if not response.content:
                return None

            try:
                return response.json()
            except Exception:
                return response.text

    async def service_types(self, *, jobcard_id: Optional[int] = None) -> list[dict[str, Any]]:
        key = f"service_types:{jobcard_id or 'limited'}"
        cached = _cache.get(key)
        if cached is not None:
            return cached

        query: dict[str, Any] = {"limited": "true"}
        if jobcard_id:
            query["jobcardID"] = jobcard_id

        data = await self._request("GET", self._services_url(f"/api/Partner/{self.cfg.partner_id}/serviceTypes", query))
        data = data or []
        _cache.set(key, data, ttl_s=1800)
        return data

    async def technicians(self) -> list[dict[str, Any]]:
        key = "technicians"
        cached = _cache.get(key)
        if cached is not None:
            return cached
        data = await self._request("GET", self._services_url(f"/api/Partner/{self.cfg.partner_id}/technicians"))
        data = data or []
        _cache.set(key, data, ttl_s=1800)
        return data

    async def pre_service_checklist(self) -> list[dict[str, Any]]:
        key = "pre_service_checklist"
        cached = _cache.get(key)
        if cached is not None:
            return cached
        data = await self._request("GET", self._api_url(f"/api/Bikeshop/{self.cfg.partner_id}/PreService/Checklist"))
        data = data or []
        _cache.set(key, data, ttl_s=1800)
        return data

    async def availability(self, start: date, end: date, service_type_ids: list[int]) -> list[dict[str, Any]]:
        query: dict[str, Any] = {
            "FromDate": start.isoformat(),
            "ToDate": end.isoformat(),
        }
        if service_type_ids:
            query["ServiceTypeID"] = ",".join(str(x) for x in service_type_ids)
        return await self._request(
            "GET",
            self._api_url(f"/api/Partner/{self.cfg.partner_id}/Workshop/Availability", query),
        ) or []

    async def find_cyclists(self, search: str, *, search_type: Optional[str] = None, limit: int = 20) -> list[dict[str, Any]]:
        query: dict[str, Any] = {
            "Page": 0,
            "Limit": limit,
            "Search": search,
        }
        if search_type:
            query["Type"] = search_type
        data = await self._request(
            "GET",
            self._api_url(f"/api/Bikeshop/{self.cfg.partner_id}/Search/Cyclists", query),
        )
        return (data or {}).get("cyclists", [])

    async def create_store_customer(
        self,
        *,
        first_name: str,
        last_name: str,
        mobile: str,
        email: Optional[str],
        manufacturer: str,
        model: str,
        colour: str,
        model_year: Optional[int],
        serial_no: Optional[str],
    ) -> dict[str, Any]:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        email_or_username = email or f"{normalize_au_mobile(mobile).replace('+', '')}@rideelectric.local"
        temp_password = f"RE-{secrets.token_urlsafe(12)}aA1!"

        payload = {
            "Name": first_name,
            "Surname": last_name,
            "Email": email or "",
            "PhoneNumber": mobile,
            "Manufacturer": manufacturer,
            "Model": model,
            "Color": colour,
            "Year": model_year or datetime.now().year,
            "SerialNo": serial_no,
            "TypeID": 99,
            "PartnerID": self.cfg.partner_id,
            "Username": email_or_username,
            "Password": temp_password,
            "ConfirmPassword": temp_password,
        }
        return await self._request("POST", self._api_url("/api/store/customers"), json_body=payload)

    async def active_bikes(self, cyclist_id: int) -> list[dict[str, Any]]:
        return await self._request(
            "GET",
            self._services_url(f"/api/Cyclist/{cyclist_id}/activebikes/partner/{self.cfg.partner_id}"),
        ) or []

    async def create_bike(
        self,
        *,
        cyclist_id: int,
        manufacturer: str,
        model: str,
        colour: str,
        model_year: Optional[int],
        serial_no: Optional[str],
    ) -> dict[str, Any]:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        payload = {
            "ID": 0,
            "UserID": cyclist_id,
            "RefNo": f"{manufacturer} - {model}",
            "SerialNo": serial_no,
            "Manufacturer": manufacturer,
            "Model": model,
            "Colour": colour or "",
            "ModelYear": model_year or "",
            "TypeID": 99,
            "LastService": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "DateBought": None,
            "StatusID": 0,
            "PartnerType": 1,
        }
        return await self._request("POST", self._services_url("/api/Bike"), json_body=payload)

    async def next_jobcard_id(self) -> int:
        value = await self._request("GET", self._services_url(f"/api/Partner/{self.cfg.partner_id}/GetNextJobcardID"))
        return int(value)

    async def schedule_service(self, payload: dict[str, Any], *, send_communication: bool = True, idempotent_mutation: bool = False) -> dict[str, Any]:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        query = {"SendCommunication": "true" if send_communication else "false"}
        return await self._request(
            "POST",
            self._services_url("/api/Partner/v3/ScheduleService", query),
            json_body=payload,
            idempotent_mutation=idempotent_mutation,
        )

    async def jobcard_search(self, req: JobSearchRequest) -> list[dict[str, Any]]:
        payload = {
            "PartnerID": self.cfg.partner_id,
            "Search": req.search,
            "SearchAllStores": req.search_all_stores,
        }
        data = await self._request("POST", self._services_url("/api/ServiceRequest/JobCardSearch"), json_body=payload)
        return data or []

    async def jobcard_get(self, jobcard_id: int) -> dict[str, Any]:
        return await self._request(
            "GET",
            self._api_url(f"/api/Portal/Workshop/Calendar/JobCard/{jobcard_id}"),
        )

    async def add_note(self, req: JobNoteAddRequest) -> dict[str, Any]:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        path = "/api/ServiceRequest/InternalNotes" if req.note_type == "internal" else "/api/ServiceRequest/AssessmentNotes"
        payload = {
            "ID": req.jobcard_id,
            "Note": req.note,
            "Date": req.date_text or now_brisbane().strftime("%d/%m/%Y"),
        }
        return await self._request("POST", self._services_url(path), json_body=payload)

    async def sku_lookup(self, query: str) -> dict[str, Any]:
        payload = {"ID": self.cfg.partner_id, "SKU": query}
        return await self._request("POST", self._services_url("/api/Partner/lstSKUAutocompleteLookupV2"), json_body=payload) or {}

    async def get_invoice(self, jobcard_id: int, *, get_from_pos: bool = True) -> dict[str, Any]:
        query = {"getFromPOS": "true" if get_from_pos else "false"}
        return await self._request("GET", self._services_url(f"/api/ServiceRequest/{jobcard_id}/GetInvoice", query))

    async def add_invoice_line_item(self, payload: dict[str, Any], *, idempotent_mutation: bool = False) -> dict[str, Any]:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        return await self._request(
            "POST",
            self._services_url("/api/Invoice/LineItem"),
            json_body=payload,
            idempotent_mutation=idempotent_mutation,
        )

    async def request_quote_approval(self, req: QuoteApprovalRequest) -> str:
        blocked = require_hubtiger_write_access()
        if blocked:
            raise PermissionError(blocked.error_code)

        job_link = f"http://hubtigerportal.azurewebsites.net//cyclist/jobcard-approval/{req.jobcard_id}?Theme={self.cfg.partner_id}"
        payload = {
            "PartnerID": self.cfg.partner_id,
            "UserID": req.cyclist_id,
            "CreatedBy": self.cfg.partner_id,
            "Title": "Your invoice has been updated",
            "Message": req.message,
            "JobURLLink": job_link,
            "JobcardNo": req.jobcard_no or req.jobcard_id,
            "SendToThirdPartyOnly": None,
        }
        result = await self._request(
            "POST",
            self._api_url(f"/api/v3/Athlete/{req.cyclist_id}/RequestApproval"),
            json_body=payload,
        )
        return result or ""


# =============================================================================
# Tool functions
# =============================================================================

async def hubtiger_booking_availability(req: BookingAvailabilityRequest) -> ToolResult:
    start_ts = time.perf_counter()
    client = HubTigerClient()

    try:
        store = "brisbane" if req.store == "newstead" else req.store
        technician_ids = client.cfg.store_technician_map.get(store, [])
        if not technician_ids:
            return ToolResult(
                success=False,
                public_message="I need the store mapping checked before I can book that properly.",
                error_code="store_mapping_missing",
            )

        end_date = req.end_date or (req.start_date + timedelta(days=14))
        raw = await client.availability(req.start_date, end_date, req.service_type_ids)

        slots: list[Slot] = []
        for item in raw:
            try:
                tech_id = int(item.get("TechnicianID") or item.get("technicianID") or 0)
                if tech_id not in technician_ids:
                    continue

                dt = parse_hub_date_time(str(item["Date"]), str(item["StartTime"]))
                if not is_bookable_slot(dt):
                    continue

                slots.append(Slot(
                    store=store,
                    date=str(item["Date"]),
                    start_time=str(item["StartTime"]),
                    end_time=str(item.get("EndTime") or ""),
                    duration_minutes=int(item.get("Duration") or 0),
                    technician_id=tech_id,
                ))
            except Exception:
                continue

        slots.sort(key=lambda s: (s.date, s.start_time))
        selected = slots[: req.limit]

        if not selected:
            return ToolResult(
                success=False,
                public_message="I can’t see a suitable workshop slot there. I can check another day or store.",
                error_code="no_slots",
                data={"slots": []},
                trace={"latency_ms": int((time.perf_counter() - start_ts) * 1000)},
            )

        first = selected[0]
        return ToolResult(
            success=True,
            public_message=f"I have a slot available at {first.start_time[:5]} on {first.date}, does that suit you?",
            data={"slots": [s.model_dump() for s in selected]},
            trace={"latency_ms": int((time.perf_counter() - start_ts) * 1000)},
        )

    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I can’t access the workshop calendar right now. I’ll connect you with a team member who can book you in and text you the time.",
            error_code="calendar_failure",
            retryable=True,
            trace={"error": str(redact(str(exc)))[:300], "latency_ms": int((time.perf_counter() - start_ts) * 1000)},
        )
    finally:
        await client.aclose()


async def hubtiger_booking_create(req: BookingCreateRequest) -> ToolResult:
    blocked = require_hubtiger_write_access()
    if blocked:
        return blocked

    start_ts = time.perf_counter()
    id_key = req.idempotency_key or _booking_idempotency_key(req)
    existing = _idempotency.get(id_key)
    if existing:
        return existing

    client = HubTigerClient()

    try:
        service_type_ids = list(req.service_type_ids)
        if req.is_first_service and not service_type_ids:
            service_type_ids = client.cfg.first_service_type_ids
        if not service_type_ids:
            service_type_ids = client.cfg.default_service_type_ids
        if not service_type_ids:
            return ToolResult(
                success=False,
                public_message="I need the service type configured before I can submit that booking.",
                error_code="service_type_missing",
            )

        mobile = normalize_au_mobile(req.mobile)
        candidates = await client.find_cyclists(mobile, search_type="Phone", limit=5)
        cyclist = candidates[0] if candidates else None

        if not cyclist:
            created = await client.create_store_customer(
                first_name=req.first_name,
                last_name=req.last_name,
                mobile=mobile,
                email=req.email,
                manufacturer=req.manufacturer,
                model=req.model,
                colour=req.colour,
                model_year=req.model_year,
                serial_no=req.serial_no,
            )
            cyclist = (created or {}).get("Data") or created

        cyclist_id = int(cyclist["ID"])
        bikes = await client.active_bikes(cyclist_id)
        bike = _find_matching_bike(bikes, req.manufacturer, req.model)

        if not bike:
            bike = await client.create_bike(
                cyclist_id=cyclist_id,
                manufacturer=req.manufacturer,
                model=req.model,
                colour=req.colour,
                model_year=req.model_year,
                serial_no=req.serial_no,
            )

        bike_id = int(bike["ID"])
        jobcard_number = await client.next_jobcard_id()
        checklist = await client.pre_service_checklist()

        service_dt = f"{req.slot.date}T{req.slot.start_time[:5]}"
        payload = {
            "ID": client.cfg.partner_id,
            "BikeID": bike_id,
            "ServiceTypes": service_type_ids,
            "ServiceDate": service_dt,
            "RequiredByDate": None,
            "PleaseBookIn": True,
            "NewJobcardID": jobcard_number,
            "Notes": req.notes or "",
            "TechnicianID": req.slot.technician_id,
            "isBikeHere": True,
            "CouponCode": "",
            "PreServiceChecklist": checklist,
            "BikeBay": "",
            "CreatedBy": client.cfg.created_by_user_id,
            "IsCollection": False,
            "IsDelivery": False,
            "CollectionInfo": None,
            "DeliveryInfo": None,
            "PreApprovedAmount": 0,
            "SelectedThirdParty": None,
            "SelectedThirdPartyIsResponsibileForPayment": False,
            "ServiceTypeQuestions": [],
        }

        scheduled = await client.schedule_service(payload, send_communication=req.send_communication, idempotent_mutation=True)

        job_id = scheduled.get("ID") if isinstance(scheduled, dict) else None
        job_no = scheduled.get("JobCardNo") if isinstance(scheduled, dict) else None

        if not job_id:
            result = ToolResult(
                success=False,
                public_message="I found your slot, but booking submission failed just now. I’ll connect you with a team member to finalise it straight away.",
                error_code="booking_submit_missing_id",
                trace={"response": redact(scheduled), "latency_ms": int((time.perf_counter() - start_ts) * 1000)},
            )
            _idempotency.set(id_key, result)
            return result

        result = ToolResult(
            success=True,
            public_message="I’ve booked that in. You’ll receive SMS updates from the Ride Electric service software shortly.",
            data={
                "jobcard_id": job_id,
                "jobcard_no": job_no,
                "cyclist_id": cyclist_id,
                "bike_id": bike_id,
                "store": req.store,
                "slot": req.slot.model_dump(),
            },
            trace={"latency_ms": int((time.perf_counter() - start_ts) * 1000)},
        )
        _idempotency.set(id_key, result)
        return result

    except Exception as exc:
        result = ToolResult(
            success=False,
            public_message="I found your slot, but booking submission failed just now. I’ll connect you with a team member to finalise it straight away.",
            error_code="booking_submit_failure",
            retryable=False,
            trace={"error": str(redact(str(exc)))[:300], "latency_ms": int((time.perf_counter() - start_ts) * 1000)},
        )
        _idempotency.set(id_key, result)
        return result
    finally:
        await client.aclose()


async def hubtiger_job_search(req: JobSearchRequest) -> ToolResult:
    start_ts = time.perf_counter()
    client = HubTigerClient()
    try:
        jobs = await client.jobcard_search(req)
        safe_jobs = [_safe_job_summary(j) for j in jobs[: req.limit]]
        if not safe_jobs:
            return ToolResult(
                success=False,
                public_message="I couldn’t find that job. Can you give me the customer name, mobile number, or job number?",
                error_code="job_not_found",
                data={"jobs": []},
            )
        return ToolResult(
            success=True,
            public_message="I found a matching job. I’ll check the details before saying anything definite.",
            data={"jobs": safe_jobs},
            trace={"latency_ms": int((time.perf_counter() - start_ts) * 1000)},
        )
    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I can’t access job details right now. I’ll get a team member to check it.",
            error_code="job_search_failure",
            retryable=True,
            trace={"error": str(redact(str(exc)))[:300]},
        )
    finally:
        await client.aclose()


async def hubtiger_job_get(req: JobGetRequest) -> ToolResult:
    client = HubTigerClient()
    try:
        job = await client.jobcard_get(req.jobcard_id)
        return ToolResult(
            success=True,
            public_message="I’ve found the job details.",
            data={"job": _safe_job_detail(job)},
        )
    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I can’t access that job right now. I’ll get a team member to check it.",
            error_code="job_get_failure",
            retryable=True,
            trace={"error": str(redact(str(exc)))[:300]},
        )
    finally:
        await client.aclose()


async def hubtiger_job_note_add(req: JobNoteAddRequest) -> ToolResult:
    blocked = require_hubtiger_write_access()
    if blocked:
        return blocked

    client = HubTigerClient()
    try:
        updated = await client.add_note(req)
        if not updated:
            return ToolResult(
                success=False,
                public_message="I couldn’t add that note just now. I’ll get a team member to follow it up.",
                error_code="note_add_no_response",
            )
        return ToolResult(
            success=True,
            public_message="I’ve added that note to the job.",
            data={"jobcard_id": req.jobcard_id, "note_type": req.note_type},
        )
    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I couldn’t add that note just now. I’ll get a team member to follow it up.",
            error_code="note_add_failure",
            retryable=False,
            trace={"error": str(redact(str(exc)))[:300]},
        )
    finally:
        await client.aclose()


async def hubtiger_products_search(req: ProductSearchRequest) -> ToolResult:
    client = HubTigerClient()
    try:
        result = await client.sku_lookup(req.query)
        products = (result or {}).get("products", [])[: req.limit] if isinstance(result, dict) else []
        safe = [_safe_product(p) for p in products]
        if not safe:
            return ToolResult(
                success=False,
                public_message="I couldn’t find that product quickly. I’ll keep the booking moving, and a team member can follow up on the quote.",
                error_code="product_not_found",
                data={"products": []},
            )
        return ToolResult(
            success=True,
            public_message="I found matching product options.",
            data={"products": safe, "exact_match": bool((result or {}).get("ExactMatch"))},
        )
    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I couldn’t check products right now. I’ll keep the booking moving, and a team member can follow up on the quote.",
            error_code="product_search_failure",
            retryable=True,
            trace={"error": str(redact(str(exc)))[:300]},
        )
    finally:
        await client.aclose()


async def hubtiger_quote_preview_price(req: QuotePreviewRequest) -> ToolResult:
    product_result = await hubtiger_products_search(ProductSearchRequest(query=req.query, limit=5))
    if not product_result.success:
        return product_result

    products = product_result.data.get("products", [])
    selected = products[0] if products else None

    if not selected:
        return ToolResult(
            success=False,
            public_message="I couldn’t find that product quickly. I’ll keep the booking moving, and a team member can follow up on the quote.",
            error_code="quote_preview_no_product",
        )

    qty = req.quantity
    inc = float(selected.get("unit_price_including_tax") or 0)
    total = round(inc * qty, 2)

    return ToolResult(
        success=True,
        public_message=f"I found {selected.get('name', 'that item')} at about ${total:.2f} including GST. Want me to add it to the quote for approval?",
        data={"selected_product": selected, "quantity": qty, "total_including_tax": total, "candidates": products},
    )


async def hubtiger_quote_add_line_item(req: QuoteAddLineItemRequest) -> ToolResult:
    blocked = require_hubtiger_write_access()
    if blocked:
        return blocked

    id_key = req.idempotency_key or _quote_line_idempotency_key(req)
    existing = _idempotency.get(id_key)
    if existing:
        return existing

    client = HubTigerClient()
    try:
        invoice_id = req.invoice_id
        if not invoice_id:
            invoice = await client.get_invoice(req.jobcard_id)
            invoice_id = int(invoice["ID"])

        product = req.product
        unit_inc = float(product.get("UnitPrice_IncludingTax") or product.get("unit_price_including_tax") or 0)
        unit_ex = float(product.get("UnitPrice") or product.get("unit_price") or round(unit_inc / 1.1, 4))
        tax = float(product.get("Tax") or product.get("tax") or round(unit_inc - unit_ex, 4))

        payload = {
            "ID": 0,
            "ExternalProductID": str(product.get("ExternalProductID") or product.get("external_product_id") or product.get("SKU") or ""),
            "SKU": str(product.get("SKU") or product.get("sku") or ""),
            "Name": str(product.get("Name") or product.get("name") or ""),
            "Description": str(product.get("Description") or product.get("description") or product.get("Name") or ""),
            "ManufacturerSKU": str(product.get("ManufacturerSKU") or ""),
            "Brand": str(product.get("Brand") or product.get("brand") or ""),
            "SystemSKU": str(product.get("SystemSKU") or ""),
            "UPC": str(product.get("UPC") or ""),
            "UnitPrice": unit_ex,
            "UnitPrice_IncludingTax": unit_inc,
            "Tax": tax,
            "EAN": str(product.get("EAN") or ""),
            "CustomSKU": str(product.get("CustomSKU") or ""),
            "wordMatch": int(product.get("wordMatch") or product.get("word_match") or 0),
            "InternalProductID": int(product.get("InternalProductID") or product.get("internal_product_id") or 0),
            "Quantity": req.quantity,
            "Discount": req.discount,
            "DiscountID": 0,
            "FoundInPOS": bool(product.get("FoundInPOS", product.get("found_in_pos", True))),
            "OriginalUnitPrice": unit_ex,
            "Price": unit_ex,
            "LightSpeedDiscounts": [],
            "InvoiceID": invoice_id,
        }

        updated_invoice = await client.add_invoice_line_item(payload, idempotent_mutation=True)
        result = ToolResult(
            success=True,
            public_message="I’ve added that to the quote. I can send the approval SMS now.",
            data={
                "invoice_id": invoice_id,
                "jobcard_id": req.jobcard_id,
                "total_price": updated_invoice.get("Total_Price") if isinstance(updated_invoice, dict) else None,
                "line_items": len(updated_invoice.get("LineItems", [])) if isinstance(updated_invoice, dict) else None,
            },
        )
        _idempotency.set(id_key, result)
        return result

    except Exception as exc:
        result = ToolResult(
            success=False,
            public_message="I couldn’t add that quote item just now. A team member will follow it up.",
            error_code="quote_add_line_failure",
            retryable=False,
            trace={"error": str(redact(str(exc)))[:300]},
        )
        _idempotency.set(id_key, result)
        return result
    finally:
        await client.aclose()


async def hubtiger_quote_request_approval_sms(req: QuoteApprovalRequest) -> ToolResult:
    blocked = require_hubtiger_write_access()
    if blocked:
        return blocked

    client = HubTigerClient()
    try:
        await client.request_quote_approval(req)
        return ToolResult(
            success=True,
            public_message="I’ve sent the quote approval SMS.",
            data={"jobcard_id": req.jobcard_id, "cyclist_id": req.cyclist_id},
        )
    except Exception as exc:
        return ToolResult(
            success=False,
            public_message="I couldn’t send the approval SMS just now. A team member will follow it up.",
            error_code="quote_approval_failure",
            retryable=False,
            trace={"error": str(redact(str(exc)))[:300]},
        )
    finally:
        await client.aclose()


# =============================================================================
# Internal helpers
# =============================================================================

def _find_matching_bike(bikes: list[dict[str, Any]], manufacturer: str, model: str) -> Optional[dict[str, Any]]:
    m = manufacturer.lower().strip()
    mo = model.lower().strip()
    for bike in bikes:
        bm = str(bike.get("Manufacturer") or "").lower().strip()
        bmo = str(bike.get("Model") or "").lower().strip()
        ref = str(bike.get("RefNo") or "").lower()
        if bm == m and bmo == mo:
            return bike
        if m in ref and mo in ref:
            return bike
    return None


def _booking_idempotency_key(req: BookingCreateRequest) -> str:
    material = {
        "mobile": normalize_au_mobile(req.mobile),
        "store": req.store,
        "slot": req.slot.model_dump(),
        "manufacturer": req.manufacturer.lower().strip(),
        "model": req.model.lower().strip(),
        "service_type_ids": req.service_type_ids,
    }
    return "booking:" + hashlib.sha256(json.dumps(material, sort_keys=True).encode()).hexdigest()


def _quote_line_idempotency_key(req: QuoteAddLineItemRequest) -> str:
    material = {
        "jobcard_id": req.jobcard_id,
        "invoice_id": req.invoice_id,
        "product": req.product.get("InternalProductID") or req.product.get("SKU") or req.product.get("name"),
        "quantity": req.quantity,
    }
    return "quote_line:" + hashlib.sha256(json.dumps(material, sort_keys=True).encode()).hexdigest()


def _safe_job_summary(job: dict[str, Any]) -> dict[str, Any]:
    return {
        "jobcard_id": job.get("ID") or job.get("JobcardID") or job.get("JobCardID"),
        "jobcard_no": job.get("JobCardNo"),
        "customer": job.get("CyclistDescription") or "Customer",
        "bike": job.get("BikeDescription"),
        "status": job.get("StatusDescription"),
        "date_checked_in": job.get("DateCheckedIn"),
        "date_required_by": job.get("DateRequiredBy"),
    }


def _safe_job_detail(job: dict[str, Any]) -> dict[str, Any]:
    return {
        "jobcard_id": job.get("ID") or job.get("JobcardID") or job.get("JobCardID"),
        "jobcard_no": job.get("JobCardNo"),
        "customer": job.get("CyclistDescription"),
        "bike": job.get("BikeDescription"),
        "status": job.get("StatusDescription"),
        "date_checked_in": job.get("DateCheckedIn"),
        "date_required_by": job.get("DateRequiredBy"),
        "technician": job.get("TechnicianDescription"),
        "client_notes": job.get("Client_Notes"),
        "initial_assessment_notes": job.get("InitialAssesment_Notes"),
        "price_estimate": job.get("PriceEstimate"),
    }


def _safe_product(product: dict[str, Any]) -> dict[str, Any]:
    return {
        "external_product_id": product.get("ExternalProductID") or product.get("externalProductID") or product.get("SKU"),
        "internal_product_id": product.get("InternalProductID") or product.get("internalProductID"),
        "sku": product.get("SKU") or product.get("sku"),
        "name": product.get("Name") or product.get("name"),
        "description": product.get("Description") or product.get("description"),
        "brand": product.get("Brand") or product.get("brand"),
        "unit_price": product.get("UnitPrice") or product.get("unitPrice"),
        "unit_price_including_tax": product.get("UnitPrice_IncludingTax") or product.get("unitPrice_IncludingTax"),
        "tax": product.get("Tax") or product.get("tax"),
        "found_in_pos": product.get("FoundInPOS", product.get("foundInPOS")),
        "_raw": product,
    }


# =============================================================================
# FastAPI endpoints
# =============================================================================

@router.post("/booking/availability", response_model=ToolResult)
async def api_booking_availability(req: BookingAvailabilityRequest) -> ToolResult:
    return await hubtiger_booking_availability(req)


@router.post("/booking/create", response_model=ToolResult)
async def api_booking_create(req: BookingCreateRequest) -> ToolResult:
    return await hubtiger_booking_create(req)


@router.post("/jobs/search", response_model=ToolResult)
async def api_job_search(req: JobSearchRequest) -> ToolResult:
    return await hubtiger_job_search(req)


@router.post("/jobs/get", response_model=ToolResult)
async def api_job_get(req: JobGetRequest) -> ToolResult:
    return await hubtiger_job_get(req)


@router.post("/jobs/note", response_model=ToolResult)
async def api_job_note_add(req: JobNoteAddRequest) -> ToolResult:
    return await hubtiger_job_note_add(req)


@router.post("/products/search", response_model=ToolResult)
async def api_products_search(req: ProductSearchRequest) -> ToolResult:
    return await hubtiger_products_search(req)


@router.post("/quotes/preview", response_model=ToolResult)
async def api_quote_preview(req: QuotePreviewRequest) -> ToolResult:
    return await hubtiger_quote_preview_price(req)


@router.post("/quotes/add-line-item", response_model=ToolResult)
async def api_quote_add_line_item(req: QuoteAddLineItemRequest) -> ToolResult:
    return await hubtiger_quote_add_line_item(req)


@router.post("/quotes/request-approval", response_model=ToolResult)
async def api_quote_approval(req: QuoteApprovalRequest) -> ToolResult:
    return await hubtiger_quote_request_approval_sms(req)

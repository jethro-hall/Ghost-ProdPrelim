import os
from datetime import date, timedelta

import pytest

from hubtiger_magic_mike_tool import (
    HubTigerAuthManager,
    HubTigerConfig,
    BookingAvailabilityRequest,
    BookingCreateRequest,
    Slot,
    ToolResult,
    _booking_idempotency_key,
    hubtiger_access_mode,
    normalize_au_mobile,
    redact,
    require_hubtiger_write_access,
    split_vehicle_name,
)


def test_normalize_au_mobile():
    assert normalize_au_mobile("0435 185 134") == "+61435185134"
    assert normalize_au_mobile("+61435185134") == "+61435185134"
    assert normalize_au_mobile("435185134") == "+61435185134"


def test_split_vehicle_name():
    assert split_vehicle_name("FatFish OG") == ("FatFish", "OG")
    assert split_vehicle_name("VSETT APEX 10+") == ("VSETT", "APEX 10+")


def test_default_access_mode_read_only(monkeypatch):
    monkeypatch.delenv("HUBTIGER_TOOL_ACCESS", raising=False)
    assert hubtiger_access_mode() == "read_only"
    blocked = require_hubtiger_write_access()
    assert blocked is not None
    assert blocked.error_code == "hubtiger_read_only_mode"


def test_read_write_access_mode(monkeypatch):
    monkeypatch.setenv("HUBTIGER_TOOL_ACCESS", "read_write")
    assert hubtiger_access_mode() == "read_write"
    assert require_hubtiger_write_access() is None


def test_invalid_access_mode_fails_closed(monkeypatch):
    monkeypatch.setenv("HUBTIGER_TOOL_ACCESS", "nonsense")
    assert hubtiger_access_mode() == "read_only"


def test_booking_availability_request_validates_limit():
    req = BookingAvailabilityRequest(
        store="brisbane",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=7),
        limit=5,
    )
    assert req.store == "brisbane"


def test_booking_idempotency_key_stable():
    slot = Slot(
        store="brisbane",
        date="2026-03-12",
        start_time="14:00:00",
        end_time="17:00:00",
        duration_minutes=180,
        technician_id=1489,
    )
    req = BookingCreateRequest(
        store="brisbane",
        slot=slot,
        first_name="Jeff",
        last_name="Hall",
        mobile="0435 185 134",
        manufacturer="VSETT",
        model="APEX 10+",
        service_type_ids=[168492],
    )
    assert _booking_idempotency_key(req).startswith("booking:")


def test_redact_auth_secrets():
    value = {
        "Authorization": "Bearer abc.def.ghi",
        "url": "https://x.test/api?code=secret123",
        "password": "supersecret",
        "legacyToken": "legacy",
    }
    redacted = redact(value)
    text = str(redacted)
    assert "supersecret" not in text
    assert "secret123" not in text
    assert "abc.def.ghi" not in text
    assert "legacy" not in text


@pytest.mark.asyncio
async def test_static_auth_headers_host_aware(monkeypatch):
    monkeypatch.setenv("HUBTIGER_AUTH_MODE", "static")
    monkeypatch.setenv("HUBTIGER_JWT_TOKEN", "jwt_token")
    monkeypatch.setenv("HUBTIGER_LEGACY_TOKEN", "legacy_token")
    monkeypatch.setenv("HUBTIGER_API_CODE", "api_code")

    cfg = HubTigerConfig.from_env()
    auth = HubTigerAuthManager(cfg)

    new_headers = await auth.auth_headers_for_url("https://hubtiger-api.azurewebsites.net/api/test?code=api_code")
    old_headers = await auth.auth_headers_for_url("https://hubtigerservices.azurewebsites.net/api/test")

    assert new_headers["Authorization"] == "Bearer jwt_token"
    assert old_headers["Authorization"] == "bearer legacy_token"

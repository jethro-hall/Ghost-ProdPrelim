# GhostDash HubTiger Magic Mike — Cursor Handover Package

## What this package is

This is the corrected HubTiger tool layer for **Magic Mike**, delivered through GhostDash.

It includes the two critical corrections:

1. HubTiger auth is not one static bearer token.
2. Magic Mike needs a server-side `read_only` / `read_write` permission gate.

## Files

```text
hubtiger_magic_mike_tool.py
hubtiger_magic_mike_env.example
hubtiger_magic_mike_tool_manifest.json
test_hubtiger_magic_mike_tool.py
CURSOR_HANDOVER.md
README.md
```

## Current intended test mode

Use:

```env
HUBTIGER_AUTH_MODE=login
HUBTIGER_TOOL_ACCESS=read_only
```

This allows:

```text
booking availability
job search
job get
product search
quote preview
```

It blocks:

```text
booking create
job note add
quote line add
quote approval SMS
customer create
bike create
schedule service
invoice mutation
request approval
```

Blocked write tools return:

```json
{
  "success": false,
  "error_code": "hubtiger_read_only_mode",
  "public_message": "I can check that for you, but booking or changes are not enabled yet.",
  "retryable": false
}
```

## HubTiger auth model

HAR evidence shows:

```text
POST hubtiger-api.azurewebsites.net/api/Auth/ValidateLogin?code=<HUBTIGER_API_CODE>
body: {"username":"...","password":"...","skipped":false}
```

Response includes:

```text
token
legacyToken
```

The tool routes tokens by host:

```text
hubtiger-api.azurewebsites.net
→ Authorization: Bearer <token>
→ plus ?code=<HUBTIGER_API_CODE>

hubtigerservices.azurewebsites.net
→ Authorization: bearer <legacyToken>
```

## Integration target

Wire the tool functions into the existing GhostDash tool router / workflow-runtime. Do not create a duplicate tool framework.

Tool functions:

```text
hubtiger_booking_availability
hubtiger_booking_create
hubtiger_products_search
hubtiger_quote_preview_price
hubtiger_quote_add_line_item
hubtiger_quote_request_approval_sms
hubtiger_job_search
hubtiger_job_get
hubtiger_job_note_add
```

## FastAPI route option

If GhostDash wants direct HTTP tool routes:

```python
from hubtiger_magic_mike_tool import router as hubtiger_router
app.include_router(hubtiger_router)
```

## Magic Mike process rules

### New booking

```text
1. Ask store.
2. Call hubtiger_booking_availability.
3. Offer exactly one slot.
4. If accepted, collect name, mobile, exact model.
5. Only call hubtiger_booking_create if HUBTIGER_TOOL_ACCESS=read_write.
6. Only claim booking success if tool returns success=true.
```

### Quote

```text
1. hubtiger_quote_preview_price
2. hubtiger_quote_add_line_item
3. hubtiger_quote_request_approval_sms
```

### Existing job

```text
1. hubtiger_job_search
2. hubtiger_job_get
3. hubtiger_job_note_add only if write access enabled
```

## Cursor proof required

Cursor must provide:

```text
1. Files changed.
2. Where the tools are registered.
3. Proof HUBTIGER_TOOL_ACCESS defaults to read_only.
4. Proof read_only allows availability/job/product/quote preview.
5. Proof read_only blocks booking/note/quote mutations.
6. Proof HubTiger login response stores token + legacyToken.
7. Proof new API uses Bearer token + code query.
8. Proof legacy services use bearer legacyToken.
9. Proof public output never exposes tokens/codes/passwords/raw errors.
10. Live or fixture availability test.
```

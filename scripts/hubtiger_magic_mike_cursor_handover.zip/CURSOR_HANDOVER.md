# Cursor Handover — Install HubTiger Magic Mike Tool Layer

## Task

Install the corrected HubTiger tool layer for Magic Mike inside GhostDash.

## Non-negotiables

Do not create a duplicate tool framework.

Before coding, inspect:

```text
workflow-runtime tool registration
agent-ingress tool calling pattern
existing HubTiger/Odoo/Shopify tool adapters
runtime profile tool permissions
production public response presenter
test layout
env/config loading pattern
```

Reuse existing GhostDash architecture.

## Package files

Use these files:

```text
hubtiger_magic_mike_tool.py
hubtiger_magic_mike_env.example
hubtiger_magic_mike_tool_manifest.json
test_hubtiger_magic_mike_tool.py
```

## Required env

Add to GhostDash env/config:

```env
HUBTIGER_TOOL_ACCESS=read_only
HUBTIGER_AUTH_MODE=login
HUBTIGER_USERNAME=
HUBTIGER_PASSWORD=
HUBTIGER_API_CODE=

HUBTIGER_PARTNER_ID=2186
HUBTIGER_CREATED_BY_USER_ID=4017336
HUBTIGER_SERVICES_BASE_URL=https://hubtigerservices.azurewebsites.net
HUBTIGER_API_BASE_URL=https://hubtiger-api.azurewebsites.net
HUBTIGER_POS_BASE_URL=https://hubtiger-pos.azurewebsites.net
HUBTIGER_STORE_TECHNICIAN_MAP_JSON={"brisbane":[1489],"newstead":[1489],"southport":[1491],"burleigh":[2188]}
HUBTIGER_FIRST_SERVICE_TYPE_IDS=
HUBTIGER_DEFAULT_SERVICE_TYPE_IDS=
```

## Permission model

Default must be `read_only`.

Allowed read-only tools:

```text
hubtiger_booking_availability
hubtiger_job_search
hubtiger_job_get
hubtiger_products_search
hubtiger_quote_preview_price
```

Blocked in read-only mode:

```text
hubtiger_booking_create
hubtiger_job_note_add
hubtiger_quote_add_line_item
hubtiger_quote_request_approval_sms
create_store_customer
create_bike
schedule_service
add_invoice_line_item
request_quote_approval
```

Do not let the LLM override access mode.

Only environment/config may move `read_only` to `read_write`.

## Auth model

Implement or preserve this exact model:

```text
ValidateLogin:
POST hubtiger-api.azurewebsites.net/api/Auth/ValidateLogin?code=<HUBTIGER_API_CODE>
body: {"username":"...","password":"...","skipped":false}

New API:
hubtiger-api.azurewebsites.net
Authorization: Bearer <token>
?code=<HUBTIGER_API_CODE>

Legacy services:
hubtigerservices.azurewebsites.net
Authorization: bearer <legacyToken>
```

Do not use one global Authorization header for all hosts.

## Public safety

Never expose to production chat:

```text
username
password
token
legacyToken
Authorization
HUBTIGER_API_CODE
raw HubTiger body
HTTP status body
stack trace
```

ToolResult.public_message is the only field Magic Mike may use directly.

## Required tool registration

Register these callable tools for Magic Mike:

```text
hubtiger_booking_availability
hubtiger_booking_create
hubtiger_products_search
hubtiger_quote_preview_price
hubtiger_quote_add_line_item
hubtiger_quote_request_approval_sms
hubtiger_job_search
hubtiger_job_get
hubtiger_job_note_add
```

## Acceptance tests

Create or adapt tests proving:

```text
1. HUBTIGER_TOOL_ACCESS unset defaults to read_only.
2. read_only allows availability lookup.
3. read_only allows job search/get.
4. read_only allows product search and quote preview.
5. read_only blocks booking create.
6. read_only blocks job note add.
7. read_only blocks quote line item add.
8. read_only blocks quote approval SMS.
9. read_write allows mutating tools subject to normal validation.
10. ValidateLogin response stores token and legacyToken.
11. hubtiger-api request uses Authorization: Bearer <token> plus code query.
12. hubtigerservices request uses Authorization: bearer <legacyToken>.
13. 401 on GET triggers re-login and one retry.
14. 401 on mutating POST does not double-submit unless idempotency allows it.
15. Logs/traces redact username/password/token/legacyToken/code.
16. Public ToolResult never exposes auth errors.
```

## Current testing mode

Do not enable writes yet.

Set:

```env
HUBTIGER_TOOL_ACCESS=read_only
```

Magic Mike can test search/availability/quote preview only.

## Proof required after implementation

Provide:

```text
git diff
files changed
tool registration path
env/config entries
test output
sample read-only blocked booking_create result
sample availability result or fixture
proof no secret appears in public response
risks / remaining unknowns
```

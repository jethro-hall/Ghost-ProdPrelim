# GhostDash Phone-Call Mode Acceptance Checklist

## Functional

- [ ] User clicks Start Call once.
- [ ] Mic remains open.
- [ ] EQ bars move with microphone input.
- [ ] Interim transcript displays.
- [ ] Interim transcript does not submit.
- [ ] Final utterance auto-submits without Send.
- [ ] Assistant text streams back.
- [ ] ElevenLabs audio starts before full response completes.
- [ ] Selected voice is heard.
- [ ] Barge-in stops assistant audio.
- [ ] Barge-in cancels active LLM stream.
- [ ] New utterance is captured and auto-sent.
- [ ] End Call stops mic, STT, TTS, audio queue, and web sockets.

## Safety

- [ ] Magic Mike resolves consumer_customer.
- [ ] Magic Mike tool policy excludes Odoo.
- [ ] No Odoo/backend/debug/citation/scorecard content is displayed.
- [ ] Unsafe text is not spoken.
- [ ] Text chat still works when voice fails.

## Network

- [ ] One backend TTS WebSocket is used.
- [ ] No repeated MP3 preview calls during phone-call mode.
- [ ] Browser never calls api.elevenlabs.io directly.
- [ ] Voice list loads from GhostDash backend.

## Proof

- [ ] Screenshot of voice selector.
- [ ] Latency metrics captured.
- [ ] Network screenshot/log.
- [ ] Test output.
- [ ] Human E2E notes.

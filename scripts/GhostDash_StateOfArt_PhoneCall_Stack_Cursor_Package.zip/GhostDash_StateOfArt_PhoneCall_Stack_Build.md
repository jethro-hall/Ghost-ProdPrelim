# GhostDash State-of-the-Art Phone-Call Voice Agent Stack — Cursor Build Document

**Project:** GhostDash  
**Feature:** Production phone-call mode for Magic Mike  
**Target:** Compete with top-tier commercial voice agents while keeping GhostDash as the source of truth  
**Priority:** Critical  
**Primary route:** `/prod_chatui/`  
**Secondary/testing route:** `/ghost_chatui/`  
**Core requirement:** The user clicks once, talks naturally, gets spoken responses, can interrupt, and never has to press Send.

---

## 1. Executive Decision

Build a dedicated **GhostCall Runtime** inside GhostDash.

Do not keep stretching the current mic button into a phone-call system.

The production voice architecture should be:

```text
Browser /prod_chatui
→ low-latency mic capture + EQ/VAD
→ GhostCall session controller
→ streaming STT
→ turn detection / endpointing
→ Magic Mike runtime
→ guarded LLM stream
→ ElevenLabs Flash v2.5 realtime TTS
→ low-latency audio playback
→ barge-in loop
```

GhostDash remains the source of truth for:

```text
agent identity
agent category
runtime profile
tool policy
guardrails
public response presenter
HubTiger/Odoo/Shopify permissions
conversation traces
cost governance
admin configuration
```

---

## 2. Recommended Stack

### Phase 1: Production-ready browser stack using existing GhostDash

Use this first because it fits the current GhostDash/GhostChat setup and is fastest to land correctly.

```text
Frontend:
  React + TypeScript
  AudioWorklet or Web Audio analyser
  WebSocket transport for PCM frames and events
  AudioContext PCM playback queue
  usePhoneCallConversation controller

Backend:
  FastAPI / Python voice-ingress service
  WebSocket session endpoint
  Deepgram Nova-3 streaming STT or equivalent streaming ASR
  VAD + endpointing
  Magic Mike runtime call
  ElevenLabs Flash v2.5 WebSocket TTS
  Postgres trace storage

STT:
  Deepgram Nova-3 streaming with interim results and endpointing

Turn detection:
  Short-term: Deepgram endpointing + local VAD threshold
  Better: Silero/WebRTC VAD + semantic EOU detector
  Best: LiveKit-style VAD + semantic turn detector

TTS:
  ElevenLabs stream-input WebSocket
  model_id: eleven_flash_v2_5
  output_format: pcm_24000
  auto_mode: true

LLM:
  Live production response: GPT-5.1 / GPT-5.1 mini depending task
  Classifier: GPT-5 nano or deterministic code
  Tool formatting: deterministic code or mini
  Complex/recovery/legal/warranty reasoning: GPT-5.1 with low/medium reasoning
```

### Phase 2: Big-league media transport

Move media transport to **LiveKit/WebRTC** once Phase 1 is stable.

This gives:

```text
lower media jitter
better browser audio handling
real session rooms
phone/SIP expansion path
agent workers
scalable multi-user voice sessions
better production observability
```

Recommended final production direction:

```text
/prod_chatui
→ LiveKit WebRTC room
→ GhostCall Agent Worker
→ Deepgram/STT
→ Magic Mike runtime
→ ElevenLabs TTS
→ LiveKit audio track back to browser
```

Do not start with a full migration unless the current GhostDash WebSocket stack cannot meet latency/reliability targets.

---

## 3. Why Not Use Browser SpeechRecognition as Production STT

Browser SpeechRecognition is acceptable for prototype/testing only.

It is not good enough for production phone-call mode because:

```text
browser support is inconsistent
latency varies
audio lifecycle is opaque
endpointing is hard to control
barge-in detection is weak
server traces are incomplete
cannot reliably tune vocabulary
harder to support mobile browsers
```

Production STT should be server-side streaming ASR.

---

## 4. Required Services

### 4.1 `ghost-chatui`

Owns:

```text
/prod_chatui
/ghost_chatui
call controls
EQ meter
phone-call state display
voice selector
audio permission UX
browser audio playback
```

Must not own:

```text
agent policy
HubTiger auth
Odoo tools
ElevenLabs API key
LLM guardrails
tool execution
```

### 4.2 `agent-ingress`

Owns:

```text
Magic Mike runtime call
production route_mode enforcement
public response presenter
retail output guard
model routing
LLM stream
trace id
tool policy selection
```

### 4.3 `voice-ingress` / `ghostcall-runtime`

Create this as a distinct backend module or service if no existing boundary fits.

Owns:

```text
phone-call websocket session
mic audio frames
STT websocket
VAD/endpointing
barge-in events
assistant audio TTS websocket
voice playback metrics
call session trace
```

Suggested route:

```text
WS /api/voice/phonecall/session
```

Subroutes already used may remain:

```text
WS /api/voice/elevenlabs/flash25/realtime
GET /api/voice/elevenlabs/voices
```

### 4.4 `workflow-runtime`

Owns:

```text
HubTiger tools
tool permissions
quote/job/booking workflows
read_only/read_write gates
tool execution traces
```

---

## 5. End-to-End Architecture

```text
Browser
  |
  | 1. Start Call
  v
/prod_chatui React UI
  |
  | PCM mic frames + call events
  v
WS /api/voice/phonecall/session
  |
  | audio stream
  v
Streaming STT provider
  |
  | interim/final transcript + endpointing
  v
Turn detector
  |
  | final utterance
  v
agent-ingress Magic Mike production runtime
  |
  | guarded assistant text deltas
  v
Retail Output Guard + PublicResponsePresenter
  |
  | safe text deltas
  v
ElevenLabs Flash v2.5 stream-input WS
  |
  | PCM audio chunks
  v
Browser AudioContext playback
```

---

## 6. State Machine

Implement in a dedicated frontend controller:

```text
usePhoneCallConversation
```

Do not bury this inside a button or chat component.

```ts
type PhoneCallState =
  | "closed"
  | "opening"
  | "listening"
  | "user_speaking"
  | "endpointing"
  | "submitting_user_turn"
  | "assistant_thinking"
  | "assistant_speaking"
  | "barge_in"
  | "stopping"
  | "error";
```

### Required state transitions

```text
closed → opening
opening → listening
listening → user_speaking
user_speaking → endpointing
endpointing → submitting_user_turn
submitting_user_turn → assistant_thinking
assistant_thinking → assistant_speaking
assistant_speaking → listening
assistant_speaking → barge_in
barge_in → user_speaking
any state → stopping
stopping → closed
any failure → error, but text chat still works
```

---

## 7. Phone-Call Transport Protocol

### Client to server

```json
{
  "type": "start_call",
  "agent_id": "magic_mike",
  "route_mode": "production_chat",
  "voice_id": "elevenlabs_voice_id",
  "sample_rate_hz": 16000,
  "encoding": "pcm_s16le",
  "turn_detection": {
    "endpointing_ms": 700,
    "barge_in_enabled": true
  }
}
```

```json
{
  "type": "audio_frame",
  "audio": "base64_pcm16",
  "timestamp_ms": 12345
}
```

```json
{
  "type": "client_event",
  "event": "end_call"
}
```

```json
{
  "type": "client_event",
  "event": "barge_in"
}
```

### Server to client

```json
{
  "type": "call_ready",
  "session_id": "uuid",
  "voice_id": "selected_voice_id"
}
```

```json
{
  "type": "transcript_interim",
  "text": "book a serv..."
}
```

```json
{
  "type": "transcript_final",
  "text": "Book a service.",
  "turn_id": "uuid"
}
```

```json
{
  "type": "assistant_text_delta",
  "text": "Sure, what store would you like"
}
```

```json
{
  "type": "assistant_audio",
  "audio": "base64_pcm16",
  "sample_rate_hz": 24000
}
```

```json
{
  "type": "metrics",
  "first_transcript_ms": 0,
  "endpoint_ms": 0,
  "first_llm_delta_ms": 0,
  "first_audio_chunk_ms": 0
}
```

```json
{
  "type": "safe_error",
  "message": "Voice is unavailable right now. Text chat still works."
}
```

---

## 8. Voice Selection

Voice selection must be first-class.

### Backend

Required endpoint:

```text
GET /api/voice/elevenlabs/voices
```

Returns:

```json
{
  "voices": [
    {
      "voice_id": "abc",
      "name": "Magic Mike",
      "category": "professional"
    }
  ]
}
```

Rules:

```text
Browser never calls api.elevenlabs.io directly.
ElevenLabs API key stays server-side.
Voice list is cached for 10-30 minutes.
```

### Frontend

Add compact selector in:

```text
Production advanced glass panel
Phone-call control strip
Agent config voice section
```

Required controls:

```text
Voice dropdown
Preview button
Save
Reset to agent default
```

Persistence:

```text
server profile if available
otherwise per-agent localStorage fallback
```

Storage key fallback:

```text
ghostdash.voice.selectedVoiceByAgent
```

---

## 9. Barge-In Design

Barge-in is GhostDash’s responsibility.

Trigger:

```text
assistant_speaking + detected user speech = barge_in
```

Detection sources:

```text
AudioWorklet/VAD energy threshold
STT speech_started event if provider supports it
interim transcript begins while assistant_speaking
```

On barge-in:

```text
1. stop browser audio queue immediately
2. cancel/close current ElevenLabs TTS stream
3. abort active LLM stream
4. stop sending current assistant deltas
5. keep microphone open
6. capture user utterance
7. submit new turn after endpoint
```

Never require the user to press Stop before interrupting.

---

## 10. Runtime Safety: Magic Mike

Phone-call mode must not bypass production safety.

Magic Mike in `/prod_chatui` must always resolve as:

```json
{
  "agent_id": "magic_mike",
  "agent_category": "consumer_customer",
  "route_mode": "production_chat",
  "public_presenter_required": true,
  "retail_output_guard_required": true,
  "diagnostics_visible": false
}
```

Forbidden in spoken/displayed Magic Mike production output:

```text
Odoo
tool blocked
backend
orchestrator
citations
scorecard
Execution Truth
Source mode
semantic
structured
provided documents
grounded information
database
```

If unsafe text appears:

```text
block it before display
block it before speech
replace with safe customer-facing fallback
```

---

## 11. Latency Targets

Target these after warm connection:

```text
Mic capture to interim transcript: < 350 ms
User endpoint after silence: 550-900 ms
Final transcript to first LLM delta: < 700 ms
First assistant delta to first audio chunk: < 500 ms
Total perceived response after user stops: 900-1600 ms
Barge-in stop audio: < 150 ms
```

If the system cannot meet this, record exact metric failure.

---

## 12. Observability

For every phone-call session, store:

```json
{
  "session_id": "uuid",
  "agent_id": "magic_mike",
  "voice_id": "redacted_or_hash",
  "stt_provider": "deepgram",
  "tts_provider": "elevenlabs",
  "llm_model": "gpt-5.1",
  "route_mode": "production_chat",
  "turn_count": 0,
  "barge_in_count": 0,
  "first_transcript_ms": 0,
  "endpoint_ms": 0,
  "first_llm_delta_ms": 0,
  "first_audio_chunk_ms": 0,
  "audio_chunks_received": 0,
  "audio_underruns": 0,
  "error_count": 0
}
```

Admin-only panel should show:

```text
state
voice ID/name
STT connection
TTS websocket
AudioContext state
first audio ms
barge-in count
last error safe summary
```

Public user sees only simple status.

---

## 13. Environment Variables

```env
# Feature gates
VITE_ENABLE_GHOSTDASH_PHONECALL_MODE=true
VITE_ENABLE_GHOSTDASH_VOICE_SNAPIN=true

# Backend voice
ELEVENLABS_API_KEY=
ELEVENLABS_DEFAULT_MODEL_ID=eleven_flash_v2_5
ELEVENLABS_DEFAULT_OUTPUT_FORMAT=pcm_24000

# STT
STT_PROVIDER=deepgram
DEEPGRAM_API_KEY=
DEEPGRAM_MODEL=nova-3
DEEPGRAM_LANGUAGE=en-AU
DEEPGRAM_ENDPOINTING_MS=700

# Runtime
MAGIC_MIKE_FORCE_CATEGORY=consumer_customer
MAGIC_MIKE_DISABLE_ODOO=true
PROD_CHAT_PUBLIC_PRESENTER_REQUIRED=true
PROD_CHAT_RETAIL_OUTPUT_GUARD_REQUIRED=true

# HubTiger testing
HUBTIGER_TOOL_ACCESS=read_only
```

---

## 14. Cursor Implementation Phases

### Phase 1 — Discovery

Cursor must inspect and document:

```text
/prod_chatui current endpoint
voice snap-in code
open streaming controller
useGhostChat lifecycle
assistant delta hooks
current voice selector state
ElevenLabs backend route
Magic Mike runtime resolution
cache/memory path causing Odoo leakage
```

Deliver:

```text
PHONECALL_RUNTIME_AUDIT.md
```

### Phase 2 — Voice selector and audio repair

Implement:

```text
GET voices endpoint if missing
VoiceSelector
per-agent persistence
resolved voice_id flow
AudioContext unlock on Start Call
PCM output enforcement
audio metrics
```

### Phase 3 — Phone-call controller

Implement:

```text
usePhoneCallConversation
state machine
auto-submit final utterance
interim display only
barge-in
end-call cleanup
```

### Phase 4 — Server-side streaming STT

Replace browser SpeechRecognition as production path with server-side streaming STT.

Browser may keep SpeechRecognition as fallback only.

### Phase 5 — Runtime contamination fix

Fix:

```text
Magic Mike category
Odoo tool exclusion
stale tool state reset
cache key separation
Retail Output Guard before display/speech
```

### Phase 6 — E2E and proof

Run:

```text
unit tests
component tests
browser E2E
manual mic/speaker E2E
network proof
latency metrics
```

---

## 15. What LLM To Build This With In Cursor

### Cursor implementation model

Use:

```text
Primary implementation: Claude Sonnet / GPT-5.1 style strong coding model
Architecture review: GPT-5.1 high reasoning or your strongest available planning model
Cheap mechanical edits: Cursor Auto / fast coding model
```

Operational rules:

```text
Max Mode OFF by default.
Do not attach the whole repo unless explicitly needed.
Work by phase and targeted files.
Use high-reasoning model only for architecture audit and final review.
Use cheaper/fast coding model for implementation, tests, and CSS.
```

### Runtime LLM for Magic Mike

Use model routing:

```text
Greeting / simple retail response:
  deterministic handler or GPT-5 nano / mini

Tool routing:
  deterministic code or nano

Normal Magic Mike response:
  GPT-5.1 with reasoning none/low, or GPT-5.1 mini if quality passes

Warranty/legal/compliance uncertainty:
  GPT-5.1 with low/medium reasoning and approved sources

Never:
  high reasoning for greetings
  flagship model for formatting
  model call for deterministic policy checks
```

---

## 16. Tests

### Unit tests

```text
VoiceSelector loads voices
selected voice persists per agent
missing voice shows "Select a voice to enable speech"
Start Call unlocks AudioContext
final transcript auto-submits once
interim transcript does not submit
barge-in aborts LLM stream and stops audio
End Call stops mic/STT/TTS/audio
unsafe Magic Mike text is not spoken
```

### Integration tests

```text
/prod_chatui sends route_mode=production_chat
Magic Mike resolves consumer_customer
Magic Mike tool policy excludes Odoo
previous Odoo blocked state does not leak into greeting
TTS websocket start payload includes voice_id and pcm_24000
audio chunks reach PCM queue
```

### Human E2E tests

```text
1. Open /prod_chatui.
2. Select Magic Mike voice.
3. Click Start Call.
4. Say: "Hi Magic, how's it going?"
5. Do not press Send.
6. Confirm text auto-sends.
7. Confirm Magic Mike responds without Odoo/debug language.
8. Confirm audio is heard before full text finishes.
9. Interrupt by saying: "Book a service."
10. Confirm audio stops and new utterance is captured.
11. End call.
12. Confirm mic/EQ/audio/websockets stop.
```

---

## 17. Acceptance Criteria

This is complete only when:

```text
1. One click starts the call.
2. The mic remains open.
3. User speech auto-submits one clean turn.
4. Interim transcripts never spam messages.
5. Magic Mike replies with safe production text.
6. ElevenLabs speaks during response streaming.
7. The selected voice is used.
8. Barge-in works without pressing Stop.
9. End Call stops all resources.
10. Text chat still works if voice fails.
11. No Odoo/backend/debug text is displayed or spoken.
12. No repeated MP3 preview calls occur.
13. Cursor provides code, tests, screenshots, network proof, and latency metrics.
```

---

## 18. Cursor Prompt

Paste this into Cursor:

```text
Build GhostDash phone-call mode as a production voice agent stack, not as a mic button.

Create a dedicated usePhoneCallConversation controller with a proper state machine:
closed, opening, listening, user_speaking, endpointing, submitting_user_turn, assistant_thinking, assistant_speaking, barge_in, stopping, error.

The user must click Start Call/Open Streaming once. After that, the mic stays open, interim transcript displays only, final transcript or silence endpoint auto-submits a single user turn, Magic Mike replies while streaming, ElevenLabs Flash v2.5 speaks from deltas, and user speech during assistant_speaking triggers barge-in.

Fix current failures:
- text auto-sends but no audio
- no voice selector
- Magic Mike leaked stale Odoo/tool content in /prod_chatui

Required:
1. Add visible voice selector.
2. Load voices from backend only.
3. Persist selected voice per agent.
4. Start Call unlocks AudioContext.
5. TTS websocket start payload includes selected voice_id, eleven_flash_v2_5, output_format pcm_24000, auto_mode true.
6. Assistant deltas go to TTS immediately.
7. PCM chunks play through AudioContext.
8. Barge-in stops audio, cancels TTS, aborts LLM stream, keeps mic open.
9. Magic Mike in /prod_chatui is consumer_customer, production_chat, public presenter required, retail output guard required.
10. Magic Mike cannot use or mention Odoo.
11. Unsafe text is blocked before display and before speech.
12. Text chat still works when voice fails.

Use server-side streaming STT for production if available; browser SpeechRecognition is fallback only. Use Deepgram Nova-3 streaming with endpointing or equivalent. Keep ElevenLabs API key server-side.

Provide:
- PHONECALL_RUNTIME_AUDIT.md
- files changed
- state machine proof
- voice selector screenshot
- websocket payload proof
- audio metrics
- before/after Magic Mike greeting
- no repeated MP3 preview proof
- human E2E notes
```

# Entity map

Use these aliases for dashboard-journal routing:
- paypal -> Retail Paypal Bank account
- vsett -> Shopify - Vsett (7095), RE Retail - Vsett Commbank, Wholesale/Retail Contra for Vsett (863)
- gst -> Retail GST Acc (4397)
- income tax -> Retail Income Tax Acc (5426)
- payroll -> Retail Payroll Acc (4307)
- amex -> American Express (61007) NEW, Retail Amex (61007)
- mastercard -> Black Mastercard (7055), Black Master card (OLD)
- cash -> Cash, Cash (SPT 2)
- contra -> Wholesale/Retail Contra (852), Retail/Burleigh Contra (851), Wholesale/Retail Contra for Vsett (863)

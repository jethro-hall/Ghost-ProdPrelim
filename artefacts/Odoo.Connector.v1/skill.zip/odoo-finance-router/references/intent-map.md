# Intent map

Prefer these report mappings:
- profitability -> Profit and Loss
- cash_position -> Cash Flow Statement
- financial_position -> Balance Sheet
- receivables -> Aged Receivables
- payables -> Aged Payables
- tax_position -> Tax Report
- budget_variance -> Budget Report
- account_activity -> General Ledger
- account_balances -> Trial Balance
- journal_activity -> Journal Report
- reconciliation_status -> Journal Dashboard / Reconciliation View

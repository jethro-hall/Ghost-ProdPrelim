---
name: odoo-finance-router
description: route business-finance questions to the correct odoo accounting report or journal dashboard source, maintain the routing registry and prompt rules, and support lean report-first agent designs for odoo finance reasoning, especially when chatgpt needs to choose between profit and loss, balance sheet, cash flow, aged receivables, aged payables, tax reports, budget reports, general ledger, partner ledger, or named journal entities like paypal, shopify, vsett, contra, gst, or cash.
---

Maintain a lean Odoo finance routing system.

## Use this skill to
- map finance questions to the best Odoo report or journal source
- update routing keywords and entity aliases
- review whether a question should use a default report or a dashboard journal
- keep prompts and registries compact for token efficiency

## Workflow
1. Read `references/intent-map.md`.
2. Read `references/entity-map.md` if the question mentions a payment rail, brand, channel, or operational account.
3. Prefer standard reports for strategic questions.
4. Prefer journal dashboard sources for reconciliation, payout, clearing, settlement, or entity-specific operational questions.
5. Return a structured route decision first.
6. Flag any ambiguity instead of inventing a source.

## Hard rules
- never route broad profitability or liquidity questions directly to a journal dashboard
- never invent a source not present in the registry
- keep routing output structured and compact
- treat journals as drill-down sources unless the user asked an operational account question

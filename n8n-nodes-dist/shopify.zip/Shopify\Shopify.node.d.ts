import type { IExecuteFunctions, ILoadOptionsFunctions, INodeExecutionData, INodePropertyOptions, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class Shopify implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getProducts(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getLocations(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=Shopify.node.d.ts.map
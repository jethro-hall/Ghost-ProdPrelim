import type { IDataObject, IExecuteFunctions, IHookFunctions, ILoadOptionsFunctions } from 'n8n-workflow';
export declare const mapOperationToJSONRPC: {
    create: string;
    get: string;
    getAll: string;
    update: string;
    delete: string;
};
export declare const mapOdooResources: {
    [key: string]: string;
};
export declare const mapFilterOperationToJSONRPC: {
    equal: string;
    notEqual: string;
    greaterThen: string;
    lesserThen: string;
    greaterOrEqual: string;
    lesserOrEqual: string;
    like: string;
    in: string;
    notIn: string;
    childOf: string;
};
export interface IOdooFilterOperations {
    filter: Array<{
        fieldName: string;
        operator: string;
        value: string;
    }>;
}
export interface IOdooNameValueFields {
    fields: Array<{
        fieldName: string;
        fieldValue: string;
    }>;
}
export interface IOdooResponseFields {
    fields: Array<{
        field: string;
        fromList?: boolean;
    }>;
}
type OdooCRUD = 'create' | 'update' | 'delete' | 'get' | 'getAll';
export declare function odooGetDBName(databaseName: string | undefined, url: string): string;
export declare function processNameValueFields(value: IDataObject): {};
export declare function odooJSONRPCRequest(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, body: IDataObject, url: string): Promise<IDataObject | IDataObject[]>;
export declare function odooGetModelFields(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, url: string): Promise<IDataObject | IDataObject[]>;
export declare function odooCreate(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, operation: OdooCRUD, url: string, newItem: IDataObject): Promise<{
    id: IDataObject | IDataObject[];
}>;
export declare function odooGet(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, operation: OdooCRUD, url: string, itemsID: string, fieldsToReturn?: IDataObject[]): Promise<IDataObject | IDataObject[]>;
export declare function odooGetAll(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, operation: OdooCRUD, url: string, filters?: IOdooFilterOperations, fieldsToReturn?: IDataObject[], limit?: number): Promise<IDataObject | IDataObject[]>;
export declare function odooUpdate(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, operation: OdooCRUD, url: string, itemsID: string, fieldsToUpdate: IDataObject): Promise<{
    id: string;
}>;
export declare function odooDelete(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, userID: number, password: string, resource: string, operation: OdooCRUD, url: string, itemsID: string): Promise<{
    success: boolean;
}>;
export declare function odooGetUserID(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, db: string, username: string, password: string, url: string): Promise<number>;
export declare function odooGetServerVersion(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, url: string): Promise<IDataObject | IDataObject[]>;
export {};
//# sourceMappingURL=GenericFunctions.d.ts.map
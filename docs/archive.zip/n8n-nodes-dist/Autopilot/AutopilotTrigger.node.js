"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutopilotTrigger = void 0;
const change_case_1 = require("change-case");
const n8n_workflow_1 = require("n8n-workflow");
const GenericFunctions_1 = require("./GenericFunctions");
class AutopilotTrigger {
    description = {
        displayName: 'Autopilot Trigger',
        name: 'autopilotTrigger',
        icon: 'file:autopilot.svg',
        group: ['trigger'],
        version: 1,
        subtitle: '={{$parameter["event"]}}',
        description: 'Handle Autopilot events via webhooks',
        defaults: {
            name: 'Autopilot Trigger',
        },
        inputs: [],
        outputs: [n8n_workflow_1.NodeConnectionTypes.Main],
        credentials: [
            {
                name: 'autopilotApi',
                required: true,
            },
        ],
        webhooks: [
            {
                name: 'default',
                httpMethod: 'POST',
                responseMode: 'onReceived',
                path: 'webhook',
            },
        ],
        properties: [
            {
                displayName: 'Event',
                name: 'event',
                type: 'options',
                required: true,
                default: '',
                options: [
                    {
                        name: 'Contact Added',
                        value: 'contactAdded',
                    },
                    {
                        name: 'Contact Added To List',
                        value: 'contactAddedToList',
                    },
                    {
                        name: 'Contact Entered Segment',
                        value: 'contactEnteredSegment',
                    },
                    {
                        name: 'Contact Left Segment',
                        value: 'contactLeftSegment',
                    },
                    {
                        name: 'Contact Removed From List',
                        value: 'contactRemovedFromList',
                    },
                    {
                        name: 'Contact Unsubscribed',
                        value: 'contactUnsubscribed',
                    },
                    {
                        name: 'Contact Updated',
                        value: 'contactUpdated',
                    },
                ],
            },
        ],
    };
    webhookMethods = {
        default: {
            async checkExists() {
                const webhookData = this.getWorkflowStaticData('node');
                const webhookUrl = this.getNodeWebhookUrl('default');
                const event = this.getNodeParameter('event');
                const { hooks: webhooks } = await GenericFunctions_1.autopilotApiRequest.call(this, 'GET', '/hooks');
                for (const webhook of webhooks) {
                    if (webhook.target_url === webhookUrl && webhook.event === (0, change_case_1.snakeCase)(event)) {
                        webhookData.webhookId = webhook.hook_id;
                        return true;
                    }
                }
                return false;
            },
            async create() {
                const webhookUrl = this.getNodeWebhookUrl('default');
                const webhookData = this.getWorkflowStaticData('node');
                const event = this.getNodeParameter('event');
                const body = {
                    event: (0, change_case_1.snakeCase)(event),
                    target_url: webhookUrl,
                };
                const webhook = await GenericFunctions_1.autopilotApiRequest.call(this, 'POST', '/hook', body);
                webhookData.webhookId = webhook.hook_id;
                return true;
            },
            async delete() {
                const webhookData = this.getWorkflowStaticData('node');
                try {
                    await GenericFunctions_1.autopilotApiRequest.call(this, 'DELETE', `/hook/${webhookData.webhookId}`);
                }
                catch (error) {
                    return false;
                }
                delete webhookData.webhookId;
                return true;
            },
        },
    };
    async webhook() {
        const req = this.getRequestObject();
        return {
            workflowData: [this.helpers.returnJsonArray(req.body)],
        };
    }
}
exports.AutopilotTrigger = AutopilotTrigger;
//# sourceMappingURL=AutopilotTrigger.node.js.map
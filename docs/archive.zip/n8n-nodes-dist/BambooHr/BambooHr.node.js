"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BambooHr = void 0;
const router_1 = require("./v1/actions/router");
const versionDescription_1 = require("./v1/actions/versionDescription");
const methods_1 = require("./v1/methods");
class BambooHr {
    description;
    constructor(baseDescription) {
        this.description = {
            ...baseDescription,
            ...versionDescription_1.versionDescription,
            usableAsTool: true,
        };
    }
    methods = {
        loadOptions: methods_1.loadOptions,
        credentialTest: methods_1.credentialTest,
    };
    async execute() {
        return [await router_1.router.call(this)];
    }
}
exports.BambooHr = BambooHr;
//# sourceMappingURL=BambooHr.node.js.map
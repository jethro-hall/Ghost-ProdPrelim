import { employeeGetAllDescription as description } from './description';
import { getAll as execute } from './execute';
export { description, execute };
//# sourceMappingURL=index.d.ts.map
import type { IExecuteFunctions, INodeExecutionData } from 'n8n-workflow';
export declare function getAll(this: IExecuteFunctions, _index: number): Promise<INodeExecutionData[]>;
//# sourceMappingURL=execute.d.ts.map
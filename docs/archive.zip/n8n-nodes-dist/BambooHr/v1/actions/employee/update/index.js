"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.description = void 0;
const description_1 = require("./description");
Object.defineProperty(exports, "description", { enumerable: true, get: function () { return description_1.employeeUpdateDescription; } });
const execute_1 = require("./execute");
Object.defineProperty(exports, "execute", { enumerable: true, get: function () { return execute_1.update; } });
//# sourceMappingURL=index.js.map
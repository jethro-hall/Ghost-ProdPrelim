import type { IExecuteFunctions, INodeExecutionData } from 'n8n-workflow';
export declare function get(this: IExecuteFunctions, index: number): Promise<INodeExecutionData[] | INodeExecutionData[][]>;
//# sourceMappingURL=execute.d.ts.map
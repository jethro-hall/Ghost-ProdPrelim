import { type IExecuteFunctions, type INodeExecutionData, type INodeProperties } from 'n8n-workflow';
export declare const description: INodeProperties[];
export declare function execute(this: IExecuteFunctions, index: number, timeout?: number): Promise<INodeExecutionData[]>;
//# sourceMappingURL=fill.operation.d.ts.map
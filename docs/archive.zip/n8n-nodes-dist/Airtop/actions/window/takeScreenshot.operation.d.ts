import type { IExecuteFunctions, INodeExecutionData, INodeProperties } from 'n8n-workflow';
export declare const description: INodeProperties[];
export declare function execute(this: IExecuteFunctions, index: number): Promise<INodeExecutionData[]>;
//# sourceMappingURL=takeScreenshot.operation.d.ts.map
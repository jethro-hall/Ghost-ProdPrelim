"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiTransform = void 0;
const n8n_workflow_1 = require("n8n-workflow");
const JsTaskRunnerSandbox_1 = require("../Code/JsTaskRunnerSandbox");
class AiTransform {
    description = {
        displayName: 'AI Transform',
        name: 'aiTransform',
        icon: 'file:aitransform.svg',
        group: ['transform'],
        version: 1,
        description: 'Modify data based on instructions written in plain english',
        defaults: {
            name: 'AI Transform',
        },
        inputs: [n8n_workflow_1.NodeConnectionTypes.Main],
        outputs: [n8n_workflow_1.NodeConnectionTypes.Main],
        parameterPane: 'wide',
        hints: [
            {
                message: "This node doesn't have access to the contents of binary files. To use those contents here, use the 'Extract from File' node first.",
                displayCondition: '={{ $input.all().some(i => i.binary) }}',
                location: 'outputPane',
            },
        ],
        properties: [
            {
                displayName: 'Instructions',
                name: 'instructions',
                type: 'button',
                default: '',
                description: "Provide instructions on how you want to transform the data, then click 'Generate code'. Use dot notation to refer to nested fields (e.g. address.street).",
                placeholder: "Example: Merge 'firstname' and 'lastname' into a field 'details.name' and sort by 'email'",
                typeOptions: {
                    buttonConfig: {
                        label: 'Generate code',
                        hasInputField: true,
                        inputFieldMaxLength: 500,
                        action: {
                            type: 'askAiCodeGeneration',
                            target: n8n_workflow_1.AI_TRANSFORM_JS_CODE,
                        },
                    },
                },
            },
            {
                displayName: 'Code Generated For Prompt',
                name: n8n_workflow_1.AI_TRANSFORM_CODE_GENERATED_FOR_PROMPT,
                type: 'hidden',
                default: '',
            },
            {
                displayName: 'Generated JavaScript',
                name: n8n_workflow_1.AI_TRANSFORM_JS_CODE,
                type: 'string',
                typeOptions: {
                    editor: 'jsEditor',
                    editorIsReadOnly: true,
                },
                default: '',
                hint: 'Read-only. To edit this code, adjust the instructions or copy and paste it into a Code node.',
                noDataExpression: true,
            },
        ],
    };
    async execute() {
        const workflowMode = this.getMode();
        const node = this.getNode();
        const code = getValidatedCode(this, node);
        const sandbox = new JsTaskRunnerSandbox_1.JsTaskRunnerSandbox(workflowMode, this);
        return [await sandbox.runCodeAllItems(code)];
    }
}
exports.AiTransform = AiTransform;
function getValidatedCode(executeFunctions, node) {
    try {
        const code = executeFunctions.getNodeParameter(n8n_workflow_1.AI_TRANSFORM_JS_CODE, 0);
        if (code) {
            return code;
        }
        const instructions = executeFunctions.getNodeParameter('instructions', 0);
        if (!instructions) {
            throw new n8n_workflow_1.NodeOperationError(node, 'Missing instructions to generate code', {
                description: "Enter your prompt in the 'Instructions' parameter and click 'Generate code'",
            });
        }
        throw new n8n_workflow_1.NodeOperationError(node, 'Missing code for data transformation', {
            description: "Click the 'Generate code' button to create the code",
        });
    }
    catch (error) {
        if (error instanceof n8n_workflow_1.NodeOperationError)
            throw error;
        throw new n8n_workflow_1.NodeOperationError(node, (0, n8n_workflow_1.ensureError)(error));
    }
}
//# sourceMappingURL=AiTransform.node.js.map
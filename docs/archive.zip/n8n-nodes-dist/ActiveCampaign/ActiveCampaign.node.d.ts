import type { IExecuteFunctions, ILoadOptionsFunctions, INodeExecutionData, INodePropertyOptions, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class ActiveCampaign implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getContactCustomFields(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getAccountCustomFields(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getTags(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=ActiveCampaign.node.d.ts.map
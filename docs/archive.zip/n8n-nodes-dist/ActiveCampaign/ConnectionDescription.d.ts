import type { INodeProperties } from 'n8n-workflow';
export declare const connectionOperations: INodeProperties[];
export declare const connectionFields: INodeProperties[];
//# sourceMappingURL=ConnectionDescription.d.ts.map
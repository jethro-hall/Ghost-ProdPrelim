import type { INodeProperties } from 'n8n-workflow';
export declare const ecomCustomerOperations: INodeProperties[];
export declare const ecomCustomerFields: INodeProperties[];
//# sourceMappingURL=EcomCustomerDescription.d.ts.map
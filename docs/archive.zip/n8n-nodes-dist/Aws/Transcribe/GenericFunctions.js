"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.awsApiRequest = awsApiRequest;
exports.awsApiRequestREST = awsApiRequestREST;
exports.awsApiRequestRESTAllItems = awsApiRequestRESTAllItems;
const aws4_1 = require("aws4");
const get_1 = __importDefault(require("lodash/get"));
const n8n_workflow_1 = require("n8n-workflow");
const url_1 = require("url");
function getEndpointForService(service, credentials) {
    let endpoint;
    if (service === 'lambda' && credentials.lambdaEndpoint) {
        endpoint = credentials.lambdaEndpoint;
    }
    else if (service === 'sns' && credentials.snsEndpoint) {
        endpoint = credentials.snsEndpoint;
    }
    else {
        endpoint = `https://${service}.${credentials.region}.amazonaws.com`;
    }
    return endpoint.replace('{region}', credentials.region);
}
async function awsApiRequest(service, method, path, body, headers) {
    const credentials = await this.getCredentials('aws');
    // Concatenate path and instantiate URL object so it parses correctly query strings
    const endpoint = new url_1.URL(getEndpointForService(service, credentials) + path);
    // Sign AWS API request with the user credentials
    const signOpts = { headers: headers || {}, host: endpoint.host, method, path, body };
    const securityHeaders = {
        accessKeyId: `${credentials.accessKeyId}`.trim(),
        secretAccessKey: `${credentials.secretAccessKey}`.trim(),
        sessionToken: credentials.temporaryCredentials
            ? `${credentials.sessionToken}`.trim()
            : undefined,
    };
    (0, aws4_1.sign)(signOpts, securityHeaders);
    const options = {
        headers: signOpts.headers,
        method,
        uri: endpoint.href,
        body: signOpts.body,
    };
    try {
        return await this.helpers.request(options);
    }
    catch (error) {
        throw new n8n_workflow_1.NodeApiError(this.getNode(), error); // no XML parsing needed
    }
}
async function awsApiRequestREST(service, method, path, body, headers) {
    const response = await awsApiRequest.call(this, service, method, path, body, headers);
    try {
        return JSON.parse(response);
    }
    catch (error) {
        return response;
    }
}
async function awsApiRequestRESTAllItems(propertyName, service, method, path, body, query = {}, _headers = {}, _option = {}, _region) {
    const returnData = [];
    let responseData;
    const propertyNameArray = propertyName.split('.');
    do {
        responseData = await awsApiRequestREST.call(this, service, method, path, body, query);
        if ((0, get_1.default)(responseData, [propertyNameArray[0], propertyNameArray[1], 'NextToken'])) {
            query.NextToken = (0, get_1.default)(responseData, [
                propertyNameArray[0],
                propertyNameArray[1],
                'NextToken',
            ]);
        }
        if ((0, get_1.default)(responseData, propertyName)) {
            if (Array.isArray((0, get_1.default)(responseData, propertyName))) {
                returnData.push.apply(returnData, (0, get_1.default)(responseData, propertyName));
            }
            else {
                returnData.push((0, get_1.default)(responseData, propertyName));
            }
        }
    } while ((0, get_1.default)(responseData, [propertyNameArray[0], propertyNameArray[1], 'NextToken']) !== undefined);
    return returnData;
}
//# sourceMappingURL=GenericFunctions.js.map
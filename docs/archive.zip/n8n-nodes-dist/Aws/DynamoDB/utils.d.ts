import type { IDataObject, INodeExecutionData } from 'n8n-workflow';
import type { AdjustedPutItem, IAttributeNameUi, IAttributeValue, IAttributeValueUi, PutItemUi } from './types';
export declare function adjustExpressionAttributeValues(eavUi: IAttributeValueUi[]): IAttributeValue;
export declare function adjustExpressionAttributeName(eanUi: IAttributeNameUi[]): {
    [key: string]: string;
};
export declare function adjustPutItem(putItemUi: PutItemUi): AdjustedPutItem;
export declare function simplify(item: IAttributeValue): IDataObject;
export declare function validateJSON(input: any): object;
export declare function copyInputItem(item: INodeExecutionData, properties: string[]): IDataObject;
export declare function mapToAttributeValues(item: IDataObject): void;
export declare function decodeItem(item: IAttributeValue): IDataObject;
//# sourceMappingURL=utils.d.ts.map
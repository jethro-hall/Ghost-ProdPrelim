import type { IExecuteFunctions, ILoadOptionsFunctions, INodeExecutionData, INodePropertyOptions, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class AwsElb implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getLoadBalancers(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getLoadBalancerListeners(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getSecurityGroups(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getSubnets(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=AwsElb.node.d.ts.map
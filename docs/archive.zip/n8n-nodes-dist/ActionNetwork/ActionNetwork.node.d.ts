import type { IExecuteFunctions, INodeExecutionData, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class ActionNetwork implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getTags(this: import("n8n-workflow").ILoadOptionsFunctions): Promise<{
                name: string;
                value: string;
            }[]>;
            getTaggings(this: import("n8n-workflow").ILoadOptionsFunctions): Promise<{
                name: string;
                value: string;
            }[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=ActionNetwork.node.d.ts.map
import type { INodeProperties } from 'n8n-workflow';
export declare const petitionOperations: INodeProperties[];
export declare const petitionFields: INodeProperties[];
//# sourceMappingURL=PetitionDescription.d.ts.map
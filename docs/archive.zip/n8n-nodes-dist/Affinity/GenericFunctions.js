"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.affinityApiRequest = affinityApiRequest;
exports.affinityApiRequestAllItems = affinityApiRequestAllItems;
exports.eventsExist = eventsExist;
exports.mapResource = mapResource;
const n8n_workflow_1 = require("n8n-workflow");
async function affinityApiRequest(method, resource, body = {}, query = {}, uri, option = {}) {
    const credentials = await this.getCredentials('affinityApi');
    const apiKey = `:${credentials.apiKey}`;
    const endpoint = 'https://api.affinity.co';
    let options = {
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Basic ${Buffer.from(apiKey).toString(n8n_workflow_1.BINARY_ENCODING)}`,
        },
        method,
        body,
        qs: query,
        uri: uri || `${endpoint}${resource}`,
        json: true,
    };
    if (!Object.keys(body).length) {
        delete options.body;
    }
    if (!Object.keys(query).length) {
        delete options.qs;
    }
    options = Object.assign({}, options, option);
    try {
        return await this.helpers.request(options);
    }
    catch (error) {
        throw new n8n_workflow_1.NodeApiError(this.getNode(), error);
    }
}
async function affinityApiRequestAllItems(propertyName, method, resource, body = {}, query = {}) {
    const returnData = [];
    let responseData;
    query.page_size = 500;
    do {
        responseData = await affinityApiRequest.call(this, method, resource, body, query);
        query.page_token = responseData.page_token;
        returnData.push.apply(returnData, responseData[propertyName]);
    } while (responseData.page_token !== undefined && responseData.page_token !== null);
    return returnData;
}
function eventsExist(subscriptions, currentSubsriptions) {
    for (const subscription of currentSubsriptions) {
        if (!subscriptions.includes(subscription)) {
            return false;
        }
    }
    return true;
}
function mapResource(key) {
    return {
        person: 'persons',
        list: 'lists',
        note: 'notes',
        organization: 'organizatitons',
        list_entry: 'list-entries',
        field: 'fields',
        file: 'files',
    }[key];
}
//# sourceMappingURL=GenericFunctions.js.map
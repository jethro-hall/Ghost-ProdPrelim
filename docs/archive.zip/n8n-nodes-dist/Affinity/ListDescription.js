"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listFields = exports.listOperations = void 0;
exports.listOperations = [
    {
        displayName: 'Operation',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        displayOptions: {
            show: {
                resource: ['list'],
            },
        },
        options: [
            {
                name: 'Get',
                value: 'get',
                description: 'Get a list',
                action: 'Get a list',
            },
            {
                name: 'Get Many',
                value: 'getAll',
                description: 'Get many lists',
                action: 'Get many lists',
            },
        ],
        default: 'get',
    },
];
exports.listFields = [
    /* -------------------------------------------------------------------------- */
    /*                                 list:get                                   */
    /* -------------------------------------------------------------------------- */
    {
        displayName: 'List ID',
        name: 'listId',
        type: 'string',
        required: true,
        default: '',
        displayOptions: {
            show: {
                resource: ['list'],
                operation: ['get'],
            },
        },
        description: 'The unique ID of the list object to be retrieved',
    },
    /* -------------------------------------------------------------------------- */
    /*                                 list:getAll                                */
    /* -------------------------------------------------------------------------- */
    {
        displayName: 'Return All',
        name: 'returnAll',
        type: 'boolean',
        displayOptions: {
            show: {
                resource: ['list'],
                operation: ['getAll'],
            },
        },
        default: false,
        description: 'Whether to return all results or only up to a given limit',
    },
    {
        displayName: 'Limit',
        name: 'limit',
        type: 'number',
        displayOptions: {
            show: {
                resource: ['list'],
                operation: ['getAll'],
                returnAll: [false],
            },
        },
        typeOptions: {
            minValue: 1,
            maxValue: 10,
        },
        default: 5,
        description: 'Max number of results to return',
    },
];
//# sourceMappingURL=ListDescription.js.map
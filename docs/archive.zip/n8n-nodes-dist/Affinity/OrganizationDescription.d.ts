import type { INodeProperties } from 'n8n-workflow';
export declare const organizationOperations: INodeProperties[];
export declare const organizationFields: INodeProperties[];
//# sourceMappingURL=OrganizationDescription.d.ts.map
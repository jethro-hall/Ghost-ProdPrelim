import type { IExecuteFunctions, ILoadOptionsFunctions, INodeExecutionData, INodePropertyOptions, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class Affinity implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getOrganizations(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getPersons(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getLists(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=Affinity.node.d.ts.map
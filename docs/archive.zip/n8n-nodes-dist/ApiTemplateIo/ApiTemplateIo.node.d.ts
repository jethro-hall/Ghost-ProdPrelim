import type { IExecuteFunctions, ILoadOptionsFunctions, INodeExecutionData, INodePropertyOptions, INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class ApiTemplateIo implements INodeType {
    description: INodeTypeDescription;
    methods: {
        loadOptions: {
            getImageTemplates(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
            getPdfTemplates(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
        };
    };
    execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]>;
}
//# sourceMappingURL=ApiTemplateIo.node.d.ts.map
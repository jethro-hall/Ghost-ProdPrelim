import type { IDataObject, IExecuteFunctions, IHookFunctions, ILoadOptionsFunctions, IHttpRequestMethods, INodePropertyOptions } from 'n8n-workflow';
/**
 * Make an API request to Asana
 *
 */
export declare function asanaApiRequest(this: IHookFunctions | IExecuteFunctions | ILoadOptionsFunctions, method: IHttpRequestMethods, endpoint: `/${string}`, body: object, query?: IDataObject, uri?: string): Promise<any>;
export declare function asanaApiRequestAllItems(this: IExecuteFunctions | ILoadOptionsFunctions, method: IHttpRequestMethods, endpoint: `/${string}`, body?: any, query?: IDataObject): Promise<any>;
export declare function getWorkspaces(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]>;
export declare function getColorOptions(): INodePropertyOptions[];
export declare function getTaskFields(): string[];
//# sourceMappingURL=GenericFunctions.d.ts.map
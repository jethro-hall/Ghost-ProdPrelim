Stack: Next.js, React, TypeScript, Tailwind. Modular provider layer for LLM + ElevenLabs.

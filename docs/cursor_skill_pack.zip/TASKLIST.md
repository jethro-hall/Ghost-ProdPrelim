1. Scaffold Next.js app
2. Build chat UI
3. Implement streaming responses
4. Add message actions
5. Optimise mobile UX

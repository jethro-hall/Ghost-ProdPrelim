MANDATORY: Every button, feature, and state must be manually human tested before signoff.

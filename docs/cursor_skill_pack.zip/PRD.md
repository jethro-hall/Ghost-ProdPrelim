Product: Browser chat app. Rich interactive, fast, modular, desktop+mobile. Use ghost_chatui as baseline.

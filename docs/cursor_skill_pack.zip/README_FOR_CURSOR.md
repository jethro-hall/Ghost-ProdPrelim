# Cursor Execution Pack
Use this repo as base. Read PRD.md then ARCHITECTURE.md then TASKLIST.md.
